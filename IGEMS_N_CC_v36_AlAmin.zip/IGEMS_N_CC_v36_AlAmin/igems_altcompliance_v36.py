"""
igems_altcompliance_v36.py
Robustness of the IGEMS mechanism ranking to the FORM of the compliance function.

Reproduces Supplementary Note S2 / Table S8 of IGEMS_N_CC_v36_AlAmin.

Three deliberately different compliance functions are applied to IDENTICAL
capacity-graded feasible effort and IDENTICAL allocations (the conserved-assumption
design), so any change in the ranking would be attributable to the functional form:

  1. geometric binary corridor   - the primary main-text metric (region-year, 0/1)
  2. logistic acceptance          - smooth, Supplementary Note S2 behavioural rule
  3. linear implementation diff.  - compliance falls linearly with required/feasible rate

Key finding:
  * Under the main-text UNWEIGHTED region-year aggregation, the ranking is preserved
    across all three forms: market least reachable (93-100% of MC draws), hybrid most
    robust (top/tied-top 58-68%), Spearman rho 0.80-1.00 between forms.
  * The equity-vs-hybrid metric-dependence noted in S2 is an AGGREGATION effect
    (population weighting), not a functional-form effect: it appears only under
    population weighting and disappears under the unweighted main-text aggregation.

Requires: numpy.  Run: python igems_altcompliance_v36.py
"""
import numpy as np
from itertools import combinations

np.random.seed(42)

# --- baseline (Table 2; emissions sum to the 36.2 Gt nine-region modelled total) ---
REG  = ['NA','EU','CHN','IND','SSA','MECA','SAS','EAP','LAM']
POP  = np.array([0.58,0.45,1.43,1.44,1.20,0.50,2.00,1.80,0.65])   # billion
GDP  = np.array([28.0,19.0,17.0,3.7,2.1,2.8,4.2,9.5,3.4])         # trillion USD
EMIS = np.array([6.5,3.6,11.0,2.4,1.2,2.2,3.2,4.3,1.8])           # Gt CO2/yr

# raw base allocation vectors
mkt = np.array([1.80,0.99,3.04,0.66,0.33,0.61,0.88,1.19,0.50])
equ = np.array([0.45,0.37,1.30,1.77,1.49,0.54,2.47,1.94,0.70])
cap = np.array([1.87,1.98,1.86,3.35,4.37,1.02,2.48,3.17,5.55])

B, T = 10.0, 50
t = np.arange(0, T + 1)
norm = lambda v: v / v.sum() * B                     # normalise each base to the 10 Gt budget
mN, eN, cN = norm(mkt), norm(equ), norm(cap)
hN = norm(0.40 * mN + 0.35 * eN + 0.25 * cN)          # convention (b): normalise-then-blend-then-renormalise
ALLOC = {'market': mN, 'equity': eN, 'capacity': cN, 'hybrid': hN}
MECH = list(ALLOC)

gpc, meanG = GDP / POP * 1000, GDP.sum() / POP.sum() * 1000

def dmax_vec(scale=1.0):
    """Capacity-graded feasible annual decarbonization rate (1.5-3.5%/yr)."""
    return np.where(gpc < 0.3*meanG, 0.015,
           np.where(gpc < 0.7*meanG, 0.020,
           np.where(gpc < 1.5*meanG, 0.025, 0.035))) * scale

def required_rate(alloc, emis):
    """Annual rate each region must sustain to reach its allocation by 2074."""
    return 1 - (alloc / emis) ** (1.0 / T)

# --- the three compliance functions (identical effort & allocations) ---
def cr_geometric(alloc, emis, dmax):                  # 1. binary corridor, region-year
    Ecap   = emis[:, None] * (alloc / emis)[:, None] ** (t[None, :] / T)
    actual = emis[:, None] * (1 - dmax)[:, None] ** t[None, :]
    return (actual <= Ecap + 1e-12).mean()

def p_logistic(alloc, emis, dmax, K=8.0, f0=1.0):     # 2. smooth logistic
    d = required_rate(alloc, emis) / dmax
    return 1 / (1 + np.exp(K * (d - f0)))

def p_linear(alloc, emis, dmax, a=0.5, b=1.0):        # 3. linear implementation difficulty
    d = required_rate(alloc, emis) / dmax
    return np.clip(1 - (d - a) / b, 0, 1)

def score(fn, alloc, emis, dmax, weighted, **kw):
    if fn == 'geometric': return cr_geometric(alloc, emis, dmax)
    P = p_logistic(alloc, emis, dmax, **kw) if fn == 'logistic' else p_linear(alloc, emis, dmax, **kw)
    return np.average(P, weights=POP) if weighted else P.mean()

FUNS = ['geometric', 'logistic', 'linear']

def deterministic(weighted):
    out = {}
    d0 = dmax_vec()
    for fn in FUNS:
        out[fn] = {m: score(fn, ALLOC[m], EMIS, d0, weighted) for m in MECH}
    return out

def monte_carlo(weighted, N=2000, thresh=0.70):
    means = {fn: {m: [] for m in MECH} for fn in FUNS}
    hyb_top = {fn: 0 for fn in FUNS}; mkt_bot = {fn: 0 for fn in FUNS}
    for _ in range(N):
        es = EMIS * np.exp(np.random.normal(0, 0.15, 9)); es = es / es.sum() * EMIS.sum()
        ds = dmax_vec(np.random.uniform(0.85, 1.15)) * np.exp(np.random.normal(0, 0.10, 9))
        kw = dict(K=np.random.uniform(6, 10), f0=np.random.uniform(0.9, 1.1))
        kwl = dict(a=np.random.uniform(0.4, 0.6), b=np.random.uniform(0.8, 1.2))
        for fn in FUNS:
            p = kw if fn == 'logistic' else (kwl if fn == 'linear' else {})
            row = {m: score(fn, ALLOC[m], es, ds, weighted, **p) for m in MECH}
            for m in MECH: means[fn][m].append(row[m])
            if abs(row['hybrid'] - max(row.values())) < 1e-9: hyb_top[fn] += 1
            if min(row, key=row.get) == 'market': mkt_bot[fn] += 1
    return means, hyb_top, mkt_bot, N

def report(weighted):
    tag = 'POPULATION-WEIGHTED' if weighted else 'UNWEIGHTED region-year (main-text aggregation)'
    print(f"\n================ {tag} ================")
    det = deterministic(weighted)
    for fn in FUNS:
        r = det[fn]
        print(f"  {fn:10}: " + "  ".join(f"{m}={r[m]:.3f}" for m in MECH) +
              f"   worst={min(r,key=r.get)}  best={max(r,key=r.get)}")
    means, hyb_top, mkt_bot, N = monte_carlo(weighted)
    for fn in FUNS:
        mn = {m: np.mean(means[fn][m]) for m in MECH}
        print(f"  MC {fn:10}: market least-reachable {mkt_bot[fn]/N*100:5.1f}% | "
              f"hybrid most-robust {hyb_top[fn]/N*100:5.1f}% | "
              + " ".join(f"{m[:3]}={mn[m]:.2f}" for m in MECH))
    print("  Spearman rank-correlation of ordering between forms:")
    rk = lambda d: {m: sorted(MECH, key=lambda x: -d[x]).index(m) for m in MECH}
    for a, b in combinations(FUNS, 2):
        x = np.array([rk(det[a])[m] for m in MECH]); y = np.array([rk(det[b])[m] for m in MECH])
        print(f"    {a} vs {b}: rho={np.corrcoef(x,y)[0,1]:+.2f}")

if __name__ == '__main__':
    report(weighted=False)   # main-text aggregation -> Table S8 (ranking preserved across forms)
    report(weighted=True)    # population-weighted    -> equity overtakes hybrid (aggregation effect)
