"""
reproduce_S7.py
===============
Reproduces every number in IGEMS Supplementary Note S7:
  Table S7.1  baseline equilibria
  Table S7.2  per-rule metrics across the 324-point parameter grid
  Table S7.3  burden concentration
  robustness sweep summary (share of grid where each rule is most cooperative)

Run:  python reproduce_S7.py
Writes a copy of the console output to ../results/expected_outputs.txt
"""
import os
import sys
import io
import igems_strategic_compliance as M

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "expected_outputs.txt")


def main():
    buf = io.StringIO()

    def w(*a):
        line = " ".join(str(x) for x in a)
        print(line); buf.write(line + "\n")

    w("=" * 74)
    w("IGEMS Supplementary Note S7  -  reproduction of all reported numbers")
    w("Model outputs (equilibria of a participation game), not empirical estimates.")
    w("=" * 74)
    w(f"Regions: {M.N}   Global abatement required (all rules): {M.TOTAL_REQ:.1f} Gt")
    w(f"Derived constants: GPC_REF={M.GPC_REF:.1f}  EQPC={M.EQPC:.4f}")

    w("\nTABLE S7.1  Endogenous equilibria at baseline (kappa=3, phi=2, rho=2)")
    w(M.table_baseline(3.0, 2.0, 2.0).to_string(index=False))
    df = M.table_baseline(3.0, 2.0, 2.0)
    order = " > ".join(df.sort_values("Q_star_Gt", ascending=False)["rule"])
    w("Ranking by delivered abatement Q*: " + order)

    w("\nTABLE S7.2  Delivered abatement Q* across the parameter grid (Gt)")
    grid, total = M.table_grid_metrics()
    w(grid.to_string(index=False))
    w(f"(grid size = {total} combinations of kappa x phi x rho)")
    w("Lowest worst-case regret (minimax): "
      + grid.loc[grid["max_regret"].idxmin(), "rule"])
    w("Highest mean delivered abatement:   "
      + grid.loc[grid["mean_Q"].idxmax(), "rule"])

    w("\nTABLE S7.3  Burden concentration by rule")
    w(M.table_burden().to_string(index=False))

    w("\nROBUSTNESS SWEEP SUMMARY  (most-cooperative rule across the grid)")
    wins, hybrid_top, total = M.sweep_summary()
    for r in M.RULES:
        w(f"   {r:9s}: {wins[r]:4d}  ({100*wins[r]/total:.1f}%)")
    w(f"   hybrid first or tied: {hybrid_top}/{total} ({100*hybrid_top/total:.1f}%)")
    w("=" * 74)

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(buf.getvalue())
    print(f"\n[written] {os.path.relpath(OUT)}")


if __name__ == "__main__":
    main()
