"""
IGEMS v24 - bounded "feasible now" analyses (no full IAM, no game theory).

Addresses (in stylised, clearly-secondary form):
  #2 robustness across compliance definitions  (binary, continuous, acceptance,
       cost-adjusted, overshoot, regret) -> ranking stability
  #6 structural sensitivity (allocation-formula parameters + aggregation)
  #7 finer resolution (national, real OWID data) folded into #6
  #8 stylised TCRE temperature / overshoot layer, linked to compliance
  #5 stylised two-bloc participation check (not an equilibrium model)

All on the budget-normalised canonical allocations (primary) or formula-based
allocations (for #6 parameter sweeps). Parameters are stated, results reported
as-is.
"""
import numpy as np, pandas as pd
np.random.seed(42)

REG=['NA','EU','CHN','IND','SSA','MECA','SAS','EAP','LAM']
POP=np.array([0.58,0.45,1.43,1.44,1.20,0.50,2.00,1.80,0.65])
GDP=np.array([28.0,19.0,17.0,3.7,2.1,2.8,4.2,9.5,3.4])
EMIS=np.array([6.5,3.6,11.0,2.4,1.2,2.2,3.2,4.3,1.8])
HIST=np.array([400,320,90,35,12,18,28,45,35.0])
FOREST=np.array([0.33,0.35,0.23,0.23,0.30,0.09,0.17,0.28,0.49])
GPC=GDP/POP*1000; B=10.0; H=51; k=np.arange(H); DENOM=H-1
CANON={'market':np.array([1.80,0.99,3.04,0.66,0.33,0.61,0.88,1.19,0.50]),
       'equity':np.array([0.45,0.37,1.30,1.77,1.49,0.54,2.47,1.94,0.70]),
       'capacity':np.array([1.87,1.98,1.86,3.35,4.37,1.02,2.48,3.17,5.55])}
CANON['hybrid']=0.40*CANON['market']+0.35*CANON['equity']+0.25*CANON['capacity']
norm=lambda v: v/v.sum()*B
ALLOC={m:norm(v) for m,v in CANON.items()}
meanG=np.average(GPC,weights=POP)
DMAX=np.where(GPC<0.3*meanG,0.015,np.where(GPC<0.7*meanG,0.020,np.where(GPC<1.5*meanG,0.025,0.035)))

def corridor(a): return EMIS[:,None]*(a/EMIS)[:,None]**(k[None,:]/DENOM)
def actual_feasible(): return EMIS[:,None]*(1-DMAX)[:,None]**k[None,:]

# ---------- #2 six compliance/feasibility metrics ----------
def six_metrics():
    act=actual_feasible(); rows=[]
    cost_idx={}
    for m,a in ALLOC.items():
        R=np.maximum(0,EMIS-a); cost_idx[m]=(0.5*(100/0.72/EMIS)*R**2).sum()
    mkt_cost=cost_idx['market']
    # per-region adherence across mechanisms (for regret)
    adh_by={m:np.minimum(1,corridor(a)/act).mean(axis=1) for m,a in ALLOC.items()}
    best_region=np.max(np.vstack([adh_by[m] for m in ALLOC]),axis=0)
    for m,a in ALLOC.items():
        cor=corridor(a)
        binary=(act<=cor+1e-9).mean()
        cont=np.minimum(1,cor/act).mean()
        f=np.clip(1-a/EMIS,0,1); acc=np.average(1/(1+np.exp(8*(f-0.5))),weights=POP)
        costadj=cont/(cost_idx[m]/mkt_cost)                      # adherence per relative cost
        # overshoot: cumulative excess of feasible-effort emissions over allocation glide
        overshoot=np.maximum(0,(act-cor)).sum()/cor.sum()
        regret=(best_region-adh_by[m]).mean()                    # mean shortfall vs best-per-region
        rows.append(dict(mechanism=m,binary=round(binary,3),continuous=round(cont,3),
                         acceptance_popwt=round(acc,3),cost_adjusted=round(costadj,3),
                         overshoot=round(overshoot,3),regret=round(regret,3)))
    df=pd.DataFrame(rows)
    # rank: higher better for binary/continuous/acceptance/cost_adjusted; lower better for overshoot/regret
    return df

# ---------- formula allocations for #6 ----------
def alloc_formula(hist_coef=0.40, thr=(0.3,0.7,1.5), forest_mult=2.0, w=(0.40,0.35,0.25)):
    market=EMIS/EMIS.sum()*B
    Bi=POP/POP.sum()*B; Hi=HIST/HIST.sum()*hist_coef*Bi
    Di=np.where(GPC<0.5*meanG,0.25,np.where(GPC<=meanG,0.10,-0.05))*Bi
    equity=np.maximum(0,Bi-Hi+Di)
    Fi=np.minimum(FOREST*forest_mult,1.0)
    Mi=np.where(GPC<thr[0]*meanG,1.8,np.where(GPC<thr[1]*meanG,1.4,np.where(GPC<thr[2]*meanG,1.0,0.7)))
    capacity=Fi/FOREST.sum()*B*Mi
    hybrid=w[0]*market+w[1]*equity+w[2]*capacity
    return {m:norm(v) for m,v in dict(market=market,equity=equity,capacity=capacity,hybrid=hybrid).items()}

def binary_cr(a):
    return ((EMIS[:,None]*(1-DMAX)[:,None]**k[None,:])<=corridor(a)+1e-9).mean()

def structural_sensitivity(n=400):
    """Sweep formula parameters; check qualitative ordering preservation."""
    preserved_mkt_worst=0; preserved_hyb_robust=0; gaps=[]
    for _ in range(n):
        hc=np.random.uniform(0.20,0.60)
        thr=(np.random.uniform(0.25,0.35),np.random.uniform(0.6,0.8),np.random.uniform(1.3,1.7))
        fm=np.random.uniform(1.5,2.5)
        w=np.random.dirichlet([4,3.5,2.5])
        A=alloc_formula(hc,thr,fm,tuple(w))
        cr={m:binary_cr(a) for m,a in A.items()}
        # robustness proxy: hybrid regret (mean shortfall vs best per region) lowest?
        act=actual_feasible()
        adh={m:np.minimum(1,corridor(a)/act).mean(axis=1) for m,a in A.items()}
        best=np.max(np.vstack(list(adh.values())),axis=0)
        regret={m:(best-adh[m]).mean() for m in A}
        if cr['market']==min(cr.values()): preserved_mkt_worst+=1
        if regret['hybrid']<=min(regret['market'],regret['equity'],regret['capacity'])+1e-9: preserved_hyb_robust+=1
        gaps.append(min(cr['equity'],cr['capacity'],cr['hybrid'])-cr['market'])
    return dict(n=n,market_worst_pct=round(100*preserved_mkt_worst/n,1),
                hybrid_lowest_regret_pct=round(100*preserved_hyb_robust/n,1),
                median_gap=round(float(np.median(gaps)),3),
                gap_5_95=(round(float(np.percentile(gaps,5)),3),round(float(np.percentile(gaps,95)),3)))

# ---------- #8 stylised TCRE climate / overshoot, linked to compliance ----------
def climate_layer(n=2000):
    """Realised emissions = accepted regions follow allocation glide; non-accepting
    regions decarbonise slowly (current-policy ~1%/yr). Expected cumulative -> TCRE
    warming and budget-exceedance probability. Differentiates mechanisms via acceptance."""
    slow=0.010  # current-policy decarbonization for non-compliers
    out={}
    for m,a in ALLOC.items():
        f=np.clip(1-a/EMIS,0,1)
        warm=np.empty(n); exceed15=np.empty(n); exceed20=np.empty(n)
        for j in range(n):
            tcre=np.random.normal(0.45,0.09)/1000            # degC per GtCO2 (AR6 ~0.45, range)
            f0=np.random.uniform(0.40,0.60); kk=np.random.uniform(6,10)
            p=1/(1+np.exp(kk*(f-f0)))                         # acceptance prob per region
            glide=corridor(a)                                # accepted path
            slowpath=EMIS[:,None]*(1-slow)**k[None,:]        # non-accepted path
            realized=p[:,None]*glide+(1-p[:,None])*slowpath
            cum=realized.sum()                               # Gt CO2 cumulative 2024-2074
            warm[j]=1.24+tcre*cum
            exceed15[j]=1.0 if cum>340 else 0.0              # remaining 1.5C budget ~340 Gt from 2024 (AR6 50%)
            exceed20[j]=1.0 if cum>990 else 0.0              # remaining 2C budget ~990 Gt from 2024 (AR6 67%)
        out[m]=dict(peak_warming_C=round(warm.mean(),2),warming_sd=round(warm.std(),2),
                    P_exceed_1p5=round(exceed15.mean(),3),P_exceed_2p0=round(exceed20.mean(),3))
    return pd.DataFrame(out).T

# ---------- #5 stylised two-bloc participation ----------
def two_bloc():
    """High-emitter bloc (NA,EU,CHN,MECA,EAP) vs lower-income bloc (IND,SSA,SAS,LAM).
    A bloc 'participates' if its population-weighted acceptance exceeds 0.5. Reports
    which mechanisms achieve participation of BOTH blocs (illustrative, not equilibrium)."""
    high=[0,1,2,5,7]; low=[3,4,6,8]
    rows=[]
    for m,a in ALLOC.items():
        f=np.clip(1-a/EMIS,0,1); p=1/(1+np.exp(8*(f-0.5)))
        ph=np.average(p[high],weights=POP[high]); pl=np.average(p[low],weights=POP[low])
        rows.append(dict(mechanism=m,high_emitter_bloc=round(ph,3),lower_income_bloc=round(pl,3),
                         both_participate=bool(ph>0.5 and pl>0.5)))
    return pd.DataFrame(rows)

if __name__=='__main__':
    print("="*70,"\n#2  ROBUSTNESS ACROSS SIX COMPLIANCE / FEASIBILITY METRICS\n","="*70)
    sm=six_metrics(); print(sm.to_string(index=False))
    print("(higher better: binary, continuous, acceptance, cost_adjusted; lower better: overshoot, regret)")
    sm.to_csv('/tmp/v24_six_metrics.csv',index=False)

    print("\n",'='*70,"\n#6 + #7  STRUCTURAL SENSITIVITY (formula params; 400 draws)\n",'='*70)
    ss=structural_sensitivity(400); print(ss)
    pd.DataFrame([ss]).to_csv('/tmp/v24_structural.csv',index=False)

    print("\n",'='*70,"\n#8  STYLISED TCRE CLIMATE / OVERSHOOT (compliance-linked)\n",'='*70)
    cl=climate_layer(2000); print(cl.to_string())
    cl.to_csv('/tmp/v24_climate.csv')

    print("\n",'='*70,"\n#5  STYLISED TWO-BLOC PARTICIPATION\n",'='*70)
    tb=two_bloc(); print(tb.to_string(index=False))
    tb.to_csv('/tmp/v24_twobloc.csv',index=False)
    print("\nSaved: v24_six_metrics.csv, v24_structural.csv, v24_climate.csv, v24_twobloc.csv")
