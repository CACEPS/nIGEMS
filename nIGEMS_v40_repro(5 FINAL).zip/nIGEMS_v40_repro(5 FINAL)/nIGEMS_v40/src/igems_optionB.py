"""
IGEMS — Option B: trajectory-convergence compliance (real simulation).

Replaces the stipulated compliance values (compliance_summary.csv) with a
genuinely simulated metric, and normalises all four allocation vectors to the
10 Gt budget (fixing the budget-conservation problem in the original package).

NON-CIRCULAR DESIGN
-------------------
Each region has a *capacity-graded feasible* maximum decarbonization rate
d_max_i, fixed by its income tier and INDEPENDENT of the allocation
(operationalising CBDR: wealthier regions can decarbonise faster). The
allocation A_i sets a target; the region exerts its best feasible effort; the
metric tests whether that effort keeps it on a glide path that converges to A_i
by 2074. Mechanisms whose allocations demand convergence faster than a region
can feasibly achieve produce non-compliance; mechanisms whose allocations are
reachable produce compliance. The allocation never defines its own pass mark,
so the metric cannot be circular.

Convergence corridor (geometric glide to the allocation):
    T_i,t = E_i,0 * (A_i / E_i,0) ** (t / H),     H = 50
Actual emissions under best feasible effort:
    E_i,t = E_i,0 * (1 - d_max_i) ** t
Compliant in year t iff  E_i,t <= T_i,t.
CR = mean over regions and years.

Capacity-graded feasible rates use the manuscript's own tested range
(1.5%-3.5%/yr), assigned by income tier. These are the only judgement
parameters; results are reported as-is, not tuned to any target.
"""
import numpy as np
import pandas as pd

H = 50
np.random.seed(42)

BASE = pd.read_csv('/tmp/igems_core/IGEMS_model/replication/IGEMS_Replication_Package/'
                   'igems_repro/data/baseline_regions.csv').set_index('region')
ALLOC = pd.read_csv('/tmp/igems_core/IGEMS_model/replication/IGEMS_Replication_Package/'
                    'igems_repro/data/base_allocations.csv').set_index('region')

E0 = BASE['current_emissions_GtCO2']
POP = BASE['population_billion']
GPC = BASE['gdp_per_capita_usd']
BUDGET = 10.0


def normalize(v):
    """Scale an allocation vector to sum exactly to the 10 Gt budget."""
    return v / v.sum() * BUDGET


def allocations_normalized():
    market = normalize(ALLOC['market_alloc_Gt'])
    equity = normalize(ALLOC['equity_alloc_Gt'])
    capacity = normalize(ALLOC['capacity_alloc_Gt'])
    hybrid = normalize(0.40*market + 0.35*equity + 0.25*capacity)
    return dict(market=market, equity=equity, capacity=capacity, hybrid=hybrid)


def feasible_rates():
    """Capacity-graded maximum feasible decarbonization rate by income tier.
    Bounds use the manuscript's tested 1.5%-3.5%/yr range. Independent of allocation."""
    mean_gpc = np.average(GPC, weights=POP)
    tiers = pd.Series(index=GPC.index, dtype=float)
    for r in GPC.index:
        ratio = GPC[r] / mean_gpc
        if ratio < 0.3:
            tiers[r] = 0.015
        elif ratio < 0.7:
            tiers[r] = 0.020
        elif ratio < 1.5:
            tiers[r] = 0.025
        else:
            tiers[r] = 0.035
    return tiers


def compliance_timeseries(alloc, dmax, e0=E0, horizon=H):
    """Return (regions x years) compliance matrix and the per-year fraction."""
    t = np.arange(horizon)
    Ei0 = e0.values[:, None]
    Ai = np.clip(alloc.values, 1e-9, None)[:, None]
    dmx = dmax.values[:, None]
    corridor = Ei0 * (Ai / Ei0) ** (t[None, :] / horizon)   # glide to allocation
    actual = Ei0 * (1 - dmx) ** t[None, :]                   # best feasible effort
    compliant = (actual <= corridor + 1e-12).astype(float)
    return compliant, compliant.mean(axis=0)


def run_deterministic():
    allocs = allocations_normalized()
    dmax = feasible_rates()
    rows, series = [], {}
    for m, a in allocs.items():
        comp, per_year = compliance_timeseries(a, dmax)
        rows.append(dict(mechanism=m, mean_compliance=round(comp.mean(), 3),
                         compliance_2024=round(per_year[0], 3),
                         compliance_2074=round(per_year[-1], 3)))
        series[m] = per_year
    return pd.DataFrame(rows), series, allocs, dmax


def run_monte_carlo(n=2000):
    allocs = allocations_normalized()
    dmax = feasible_rates().values
    t = np.arange(H)
    out = {}
    # uncertainty: emissions (lognormal 15% CV), feasible-rate multiplier (beta), annual shock (gamma, unit mean)
    for m, a in allocs.items():
        Ai = np.clip(a.values, 1e-9, None)
        cr = np.empty(n)
        for k in range(n):
            emult = np.random.lognormal(-0.5*np.log(1.15)**2, np.log(1.15), len(a))
            rmult = np.random.beta(8, 8, len(a)) * 0.6 + 0.7      # 0.7-1.3x on feasible rate
            shock = np.random.gamma(9, 1/9, len(a))                # unit-mean
            Ei0 = E0.values * emult
            d = np.clip(dmax * rmult, 0.005, 0.06)
            corridor = Ei0[:, None] * (Ai/Ei0)[:, None] ** (t[None, :]/H)
            actual = (Ei0[:, None] * (1 - d)[:, None] ** t[None, :]) * shock[:, None]
            cr[k] = (actual <= corridor + 1e-12).mean()
        out[m] = dict(mean=round(cr.mean(), 3), sd=round(cr.std(), 3),
                      lo=round(np.percentile(cr, 2.5), 3),
                      hi=round(np.percentile(cr, 97.5), 3),
                      p_high=round(float(np.mean(cr > 0.70)), 3))
    return pd.DataFrame(out).T


if __name__ == '__main__':
    print("Capacity-graded feasible decarbonization rates (independent of allocation):")
    print(feasible_rates().to_string(), "\n")

    print("Allocations normalised to 10 Gt (sums):")
    allocs = allocations_normalized()
    print("  " + ", ".join(f"{m}={a.sum():.2f}" for m, a in allocs.items()), "\n")

    det, series, allocs, dmax = run_deterministic()
    print("="*64, "\nDETERMINISTIC trajectory-convergence compliance (Option B)\n", "="*64)
    print(det.to_string(index=False))

    # success-probability bands (manuscript Sec 3.6), applied to the SIMULATED CR
    def band(cr): return 0.85 if cr > 0.70 else (0.50 if cr >= 0.40 else 0.20)
    det['success_prob_1p5C'] = det['mean_compliance'].apply(band)
    print("\nMapped through the manuscript's success-probability bands:")
    print(det[['mechanism', 'mean_compliance', 'success_prob_1p5C']].to_string(index=False))

    print("\n", "="*64, "\nMONTE CARLO (2000 runs) under input uncertainty\n", "="*64)
    mc = run_monte_carlo(2000)
    print(mc.to_string())

    det.to_csv('/tmp/B_compliance_summary.csv', index=False)
    mc.to_csv('/tmp/B_montecarlo.csv')
    pd.DataFrame(series, index=range(2024, 2024+H)).round(3).to_csv('/tmp/B_compliance_timeseries.csv')
    print("\nSaved: B_compliance_summary.csv, B_montecarlo.csv, B_compliance_timeseries.csv")
