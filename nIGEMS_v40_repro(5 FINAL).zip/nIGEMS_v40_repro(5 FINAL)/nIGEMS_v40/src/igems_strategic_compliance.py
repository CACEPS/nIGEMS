"""
igems_strategic_compliance.py
=============================
Endogenous strategic compliance as a participation game (IGEMS Supplementary Note S7).

Compliance is NOT imposed. Each of the nine regions chooses comply or defect by best
response. The realised compliance profile is a Nash equilibrium of an international
environmental agreement (IEA) participation game (Barrett 1994; d'Aspremont et al. 1983
stability), augmented with a per-capita fairness/legitimacy term and a reciprocity term.

Region i complies iff the gain from complying rather than defecting is non-negative:

    Delta_i(S) = q_i - C_i + phi * F_i + rho * |S_{-i}| / (N - 1)              (benefit b = 1)

    q_i = max(0, E_i - alloc_i^rule)                       own abatement (Gt)
    C_i = kappa * (q_i^2 / E_i) * (g_ref / g_i)            convex, capacity-scaled cost
    F_i = min(1, (alloc_i^rule / P_i) / eqpc)              per-capita legitimacy, capped at 1

A profile S is a Nash equilibrium iff no complier wants to leave and no defector wants
to join. We enumerate all 2^9 = 512 profiles, find every equilibrium, and report the
Pareto-best (largest delivered abatement) self-enforcing outcome per rule.

ALL NUMBERS ARE MODEL OUTPUTS, not empirical estimates. The point is the endogenous
RANKING of allocation rules and its robustness, not the level of any single figure.

Inputs are read from ../data/*.csv so the data provenance is explicit. The values match
the IGEMS main-model baseline (Table 1 / Table 5).
"""

import os
import itertools
import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
_DATA = os.path.join(_HERE, "..", "data")


def load_data(data_dir=_DATA):
    # keep_default_na=False so the region code "NA" (North America) is not read as missing
    base = pd.read_csv(os.path.join(data_dir, "data_baseline_regions.csv"), keep_default_na=False)
    alloc = pd.read_csv(os.path.join(data_dir, "data_allocations.csv"), keep_default_na=False)
    for c in ["emissions_Gt", "population_bn", "gdp_tn_usd", "gdp_per_capita_usd"]:
        base[c] = base[c].astype(float)
    for c in ["market", "equity", "capacity", "hybrid"]:
        alloc[c] = alloc[c].astype(float)
    base = base.set_index("region")
    alloc = alloc.set_index("region").loc[base.index]
    REG = list(base.index)
    E = base["emissions_Gt"].to_numpy(float)
    P = base["population_bn"].to_numpy(float)
    GPC = base["gdp_per_capita_usd"].to_numpy(float)
    ALLOC = {c: alloc[c].to_numpy(float) for c in ["market", "equity", "capacity", "hybrid"]}
    return REG, E, P, GPC, ALLOC


REG, E, P, GPC, ALLOC = load_data()
N = len(REG)
GPC_REF = (GPC * P).sum() / P.sum()      # population-weighted mean GDP per capita
EQPC = 10.0 / P.sum()                      # equal-per-capita allocation (Gt per billion)
TOTAL_REQ = E.sum() - 10.0                  # global abatement required = 26.2 Gt (all rules)
RULES = ["market", "equity", "capacity", "hybrid"]


def region_terms(rule):
    a = ALLOC[rule]
    q = np.maximum(0.0, E - a)
    C_unit = (q ** 2 / E) * (GPC_REF / GPC)
    F = np.minimum(1.0, (a / P) / EQPC)
    return q, C_unit, F


def nash_equilibria(rule, kappa, phi, rho):
    q, C_unit, F = region_terms(rule)
    C = kappa * C_unit
    base = q - C + phi * F
    eqs = []
    for bits in itertools.product([0, 1], repeat=N):
        S = np.array(bits, dtype=bool)
        nS = int(S.sum())
        ok = True
        for i in range(N):
            others = nS - (1 if S[i] else 0)
            delta = base[i] + rho * others / (N - 1)
            if S[i] and delta < 0:
                ok = False; break
            if (not S[i]) and delta >= 0:
                ok = False; break
        if ok:
            Q = float(q[S].sum())
            eqs.append({"coalition": tuple(np.array(REG)[S]), "n": nS,
                        "Q_delivered_Gt": Q,
                        "global_compliance": Q / TOTAL_REQ,
                        "emis_wt_compliance": float(E[S].sum() / E.sum())})
    return eqs


def best_equilibrium(rule, kappa, phi, rho):
    eqs = nash_equilibria(rule, kappa, phi, rho)
    return max(eqs, key=lambda d: d["Q_delivered_Gt"]), len(eqs)


def dasp_stable(rule, kappa, phi, rho, coalition_names):
    q, C_unit, F = region_terms(rule); C = kappa * C_unit
    S = np.array([r in coalition_names for r in REG]); nS = int(S.sum())
    internal = all((q[i] - C[i] + phi * F[i] + rho * (nS - 1) / (N - 1)) >= 0
                   for i in np.where(S)[0])
    external = all((q[j] - C[j] + phi * F[j] + rho * nS / (N - 1)) < 0
                   for j in np.where(~S)[0])
    return bool(internal), bool(external)


# ----- Table S7.1 : baseline equilibria -----
def table_baseline(kappa=3.0, phi=2.0, rho=2.0):
    rows = []
    for rule in RULES:
        best, _ = best_equilibrium(rule, kappa, phi, rho)
        intern, extern = dasp_stable(rule, kappa, phi, rho, best["coalition"])
        rows.append({"rule": rule, "compliers": best["n"],
                     "stable_coalition": "+".join(best["coalition"]) or "(none)",
                     "Q_star_Gt": round(best["Q_delivered_Gt"], 2),
                     "global_compliance": round(best["global_compliance"], 3),
                     "emis_wt_compliance": round(best["emis_wt_compliance"], 3),
                     "dAsp_internal": intern, "dAsp_external": extern})
    return pd.DataFrame(rows)


def _grid(kappa_grid, phi_grid, rho_grid):
    for kappa in kappa_grid:
        for phi in phi_grid:
            for rho in rho_grid:
                yield kappa, phi, rho


def default_grid():
    return [2.0, 3.0, 4.0, 5.0], list(np.linspace(0, 4, 9)), list(np.linspace(0, 4, 9))


# ----- Table S7.2 : per-rule metrics across the parameter grid -----
def table_grid_metrics(kappa_grid=None, phi_grid=None, rho_grid=None):
    kg, pg, rg = default_grid()
    kappa_grid = kappa_grid or kg; phi_grid = phi_grid or pg; rho_grid = rho_grid or rg
    Q = {r: [] for r in RULES}; regret = {r: [] for r in RULES}
    for kappa, phi, rho in _grid(kappa_grid, phi_grid, rho_grid):
        qstar = {r: best_equilibrium(r, kappa, phi, rho)[0]["Q_delivered_Gt"] for r in RULES}
        best = max(qstar.values())
        for r in RULES:
            Q[r].append(qstar[r]); regret[r].append(best - qstar[r])
    rows = []
    total = len(Q[RULES[0]])
    for r in RULES:
        a = np.array(Q[r]); g = np.array(regret[r])
        first = sum(1 for i in range(total) if Q[r][i] >= max(Q[x][i] for x in RULES) - 1e-9)
        rows.append({"rule": r, "mean_Q": round(a.mean(), 2), "worst_case_Q": round(a.min(), 2),
                     "best_case_Q": round(a.max(), 2), "max_regret": round(g.max(), 2),
                     "mean_regret": round(g.mean(), 2),
                     "share_first": f"{100*first/total:.1f}%"})
    return pd.DataFrame(rows), total


# ----- Table S7.3 : burden concentration -----
def table_burden():
    rows = []
    for r in RULES:
        cut = np.maximum(0, E - ALLOC[r]) / E * 100
        rows.append({"rule": r, "max_single_region_cut_pct": int(round(cut.max())),
                     "mean_cut_pct": int(round(cut.mean()))})
    return pd.DataFrame(rows)


# ----- robustness sweep summary (share of grid where each rule is most cooperative) -----
def sweep_summary(kappa_grid=None, phi_grid=None, rho_grid=None):
    kg, pg, rg = default_grid()
    kappa_grid = kappa_grid or kg; phi_grid = phi_grid or pg; rho_grid = rho_grid or rg
    wins = {r: 0 for r in RULES}; hybrid_top = 0; total = 0
    for kappa, phi, rho in _grid(kappa_grid, phi_grid, rho_grid):
        qstar = {r: best_equilibrium(r, kappa, phi, rho)[0]["Q_delivered_Gt"] for r in RULES}
        top = max(qstar, key=qstar.get); wins[top] += 1
        if qstar["hybrid"] >= max(qstar.values()) - 1e-9:
            hybrid_top += 1
        total += 1
    return wins, hybrid_top, total


if __name__ == "__main__":
    print("N regions:", N, "| global abatement required (Gt):", round(TOTAL_REQ, 1))
    print("\nTable S7.1 (baseline kappa=3, phi=2, rho=2):")
    print(table_baseline().to_string(index=False))
