"""
IGEMS Supplementary stylised IAM layer (per co-author guidance).

Bounded, transparent, clearly SECONDARY feasibility check. It does NOT feed the
main governance result; it only asks whether the IGEMS mechanism ranking
survives when regional mitigation COSTS are considered.

Design (deliberately simple and documented):
  * Each region i abates from current emissions E_i,0 to its (budget-normalised)
    IGEMS allocation A_i.  Required abatement R_i = max(0, E_i,0 - A_i)  [Gt/yr].
  * Convex regional marginal abatement cost (MAC), linear in abatement so total
    cost is quadratic:  MAC_i(q) = b_i * q ;  C_i = 0.5 * b_i * R_i^2.
  * Regional slope b_i = k / E_i,0  (larger emitters have deeper low-cost
    abatement potential -> flatter MAC). The implied marginal (carbon) price at
    the required cut is p_i = b_i * R_i = k * (R_i / E_i,0) = k * f_i, i.e. it
    rises with the DEPTH of the cut as a fraction f_i of current emissions.
  * k is calibrated so a 72% cut implies ~$100/t (IMF/Nordhaus-consistent),
    k = 100 / 0.72.  Costs are reported as an index (market = 100) plus the
    implied global average price and the regional cost distribution, so no
    over-precise dollar claim is made.

Allocations are the same budget-normalised vectors used in the main analysis.
The IAM layer takes them as fixed exogenous constraints; it never re-optimises
them. This keeps the main governance result independent of any IAM assumption.
"""
import numpy as np
import pandas as pd

BASE = pd.read_csv('/tmp/igems_core/IGEMS_model/replication/IGEMS_Replication_Package/'
                   'igems_repro/data/baseline_regions.csv').set_index('region')
ALLOC = pd.read_csv('/tmp/igems_core/IGEMS_model/replication/IGEMS_Replication_Package/'
                    'igems_repro/data/base_allocations.csv').set_index('region')
E0 = BASE['current_emissions_GtCO2']
BUDGET = 10.0
K = 100.0 / 0.72   # calibration: 72% cut -> ~$100/t marginal


def norm(v): return v / v.sum() * BUDGET


def allocs():
    m, e, c = norm(ALLOC['market_alloc_Gt']), norm(ALLOC['equity_alloc_Gt']), norm(ALLOC['capacity_alloc_Gt'])
    h = norm(0.40*m + 0.35*e + 0.25*c)
    return dict(market=m, equity=e, capacity=c, hybrid=h)


def mac_costs():
    b = K / E0                          # regional MAC slope
    rows, reg_costs = [], {}
    for mech, a in allocs().items():
        R = (E0 - a).clip(lower=0.0)    # required abatement, Gt/yr
        C = 0.5 * b * R**2              # convex regional cost
        price = (b * R)                 # implied marginal price $/t at required cut
        reg_costs[mech] = C
        rows.append(dict(mechanism=mech,
                         total_cost=float(C.sum()),
                         mean_price_usd_t=float(np.average(price, weights=E0)),
                         cost_top2_share=float((C.nlargest(2).sum()) / C.sum())))
    df = pd.DataFrame(rows)
    df['cost_index_market100'] = (df['total_cost'] / df.loc[df.mechanism=='market','total_cost'].iloc[0] * 100).round(1)
    df['total_cost'] = df['total_cost'].round(2)
    df['mean_price_usd_t'] = df['mean_price_usd_t'].round(0)
    df['cost_top2_share'] = (df['cost_top2_share']*100).round(1)
    return df[['mechanism','cost_index_market100','mean_price_usd_t','cost_top2_share']], pd.DataFrame(reg_costs).round(3)


if __name__ == '__main__':
    summary, regional = mac_costs()
    print("Stylised IAM layer — mitigation cost by mechanism (allocations fixed exogenously)")
    print("="*72)
    print(summary.to_string(index=False))
    print("\nRegional cost distribution (cost index, sums match totals):")
    print(regional.to_string())
    print("\nRanking check (governance ranking: hybrid/equity > capacity > market):")
    s = summary.set_index('mechanism')['cost_index_market100']
    print(f"  cost index — market={s['market']}, capacity={s['capacity']}, "
          f"equity={s['equity']}, hybrid={s['hybrid']}")
    summary.to_csv('/tmp/S_iam_cost_summary.csv', index=False)
    regional.to_csv('/tmp/S_iam_cost_regional.csv')
    print("\nSaved: S_iam_cost_summary.csv, S_iam_cost_regional.csv")
