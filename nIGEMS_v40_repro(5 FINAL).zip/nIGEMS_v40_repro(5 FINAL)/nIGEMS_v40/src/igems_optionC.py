"""
IGEMS - Option C: acceptance-weighted compliance (behavioural mechanism).

FOR COMPARATIVE STUDY. The group selected Option B for the manuscript; this
module is a parallel behavioural specification, kept separate.

Idea (grounded in the political-acceptance / fair-burden literature): a region's
probability of complying with its allocation declines as the required cut from
current emissions deepens. Allocations a region perceives as unfairly demanding
are resisted; allocations at or above current emissions (a development surplus)
are readily accepted.

Required cut for region i under allocation A_i:
    f_i = max(0, 1 - A_i / E_i0)            (0 = no cut/surplus; 1 = full cut)

Acceptance (compliance) probability - logistic in cut depth:
    p_i = 1 / (1 + exp( k * (f_i - f0) ))
  f0 = cut depth at which acceptance = 0.5 (political tolerance midpoint)
  k  = steepness of the acceptance decline

Two variants:
  (1) Uniform tolerance: same f0 for all regions.
  (2) Capacity-adjusted tolerance (CBDR): wealthier regions tolerate deeper cuts,
      f0_i = f0_base + span * (gpc_i / max gpc). This also answers comment 3 by
      tying acceptance to common-but-differentiated capacity.

Mechanism compliance = mean acceptance over regions (unweighted and population-
weighted). A Monte Carlo over the behavioural parameters (f0, k) and emissions
gives the simulated distribution, 95% interval, and P(CR > 0.70).

Parameters are stated, not tuned to a target; results are reported as-is.
"""
import numpy as np
import pandas as pd

np.random.seed(42)

REG = ['NA','EU','CHN','IND','SSA','MECA','SAS','EAP','LAM']
POP = np.array([0.58,0.45,1.43,1.44,1.20,0.50,2.00,1.80,0.65])      # billions
EMIS = np.array([6.5,3.6,11.0,2.4,1.2,2.2,3.2,4.3,1.8])              # Gt/yr
GPC = np.array([48276,42222,11930,2569,1750,5600,2100,5278,5231.0])  # $/cap
BUDGET = 10.0

# canonical base allocations (base_allocations.csv), normalised to the budget
ALLOC_RAW = {
    'market':   np.array([1.80,0.99,3.04,0.66,0.33,0.61,0.88,1.19,0.50]),
    'equity':   np.array([0.45,0.37,1.30,1.77,1.49,0.54,2.47,1.94,0.70]),
    'capacity': np.array([1.87,1.98,1.86,3.35,4.37,1.02,2.48,3.17,5.55]),
}
ALLOC_RAW['hybrid'] = 0.40*ALLOC_RAW['market'] + 0.35*ALLOC_RAW['equity'] + 0.25*ALLOC_RAW['capacity']
ALLOC = {m: v / v.sum() * BUDGET for m, v in ALLOC_RAW.items()}

# stated behavioural parameters
F0_BASE = 0.50      # 50% cut = half-acceptance midpoint
K_STEEP = 8.0       # steepness
SPAN = 0.30         # capacity tolerance span (variant 2)


def required_cut(alloc, e0=EMIS):
    return np.clip(1.0 - alloc / e0, 0.0, 1.0)


def acceptance(f, f0=F0_BASE, k=K_STEEP):
    return 1.0 / (1.0 + np.exp(k * (f - f0)))


def f0_capacity():
    return F0_BASE + SPAN * (GPC / GPC.max())   # richer regions tolerate deeper cuts


def deterministic():
    f0_cap = f0_capacity()
    rows, detail = [], {}
    for m, a in ALLOC.items():
        f = required_cut(a)
        p_uni = acceptance(f)                       # uniform tolerance
        p_cap = acceptance(f, f0=f0_cap)            # capacity-adjusted tolerance
        rows.append(dict(
            mechanism=m,
            CR_uniform=round(p_uni.mean(), 3),
            CR_uniform_popwt=round(np.average(p_uni, weights=POP), 3),
            CR_capacity_adj=round(p_cap.mean(), 3),
            CR_capacity_popwt=round(np.average(p_cap, weights=POP), 3),
        ))
        detail[m] = pd.Series(np.round(p_uni, 3), index=REG)
    return pd.DataFrame(rows), pd.DataFrame(detail)


def monte_carlo(n=2000):
    """Vary behavioural parameters (f0, k) and emissions; report distribution."""
    out = {}
    for m, a in ALLOC.items():
        cr = np.empty(n)
        for j in range(n):
            emult = np.random.lognormal(-0.5*np.log(1.15)**2, np.log(1.15), len(a))
            f0 = np.random.uniform(0.40, 0.60)
            k = np.random.uniform(6.0, 10.0)
            f = np.clip(1.0 - a / (EMIS*emult), 0.0, 1.0)
            cr[j] = np.average(acceptance(f, f0, k), weights=POP)   # population-weighted
        out[m] = dict(mean=round(cr.mean(), 3), sd=round(cr.std(), 3),
                      lo=round(np.percentile(cr, 2.5), 3),
                      hi=round(np.percentile(cr, 97.5), 3),
                      p_high=round(float(np.mean(cr > 0.70)), 3))
    return pd.DataFrame(out).T


if __name__ == '__main__':
    print("OPTION C - acceptance-weighted compliance (for comparative study)")
    print("Stated parameters: f0 =", F0_BASE, " k =", K_STEEP, " capacity span =", SPAN, "\n")

    det, detail = deterministic()
    print("Deterministic expected compliance by mechanism")
    print("="*64)
    print(det.to_string(index=False))

    print("\nPer-region acceptance probability (uniform tolerance) - the behavioural")
    print("mechanism that answers reviewer comment 3:")
    print(detail.to_string())

    print("\nMonte Carlo (2000 runs; varies f0, k, emissions; population-weighted)")
    print("="*64)
    mc = monte_carlo(2000)
    print(mc.to_string())

    det.to_csv('/tmp/C_compliance_summary.csv', index=False)
    detail.to_csv('/tmp/C_region_acceptance.csv')
    mc.to_csv('/tmp/C_montecarlo.csv')
    print("\nSaved: C_compliance_summary.csv, C_region_acceptance.csv, C_montecarlo.csv")
