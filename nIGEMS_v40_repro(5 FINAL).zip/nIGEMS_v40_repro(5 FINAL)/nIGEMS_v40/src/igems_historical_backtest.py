"""
igems_historical_backtest.py
============================
Historical back-test of the four IGEMS allocation rules against
  (Q1) observed NDC ambition, and
  (Q2) actual emissions shares and trajectories.

This is a CORRECTED and completed version of the user's draft script. Changes:
  * Generates the two IGEMS files the original needed (igems_allocations_2030.csv,
    igems_allocations_static_share.csv) from the rule vectors below.
  * Reads CSVs with keep_default_na=False, so the region code "NA" (North America)
    is not silently parsed as a missing value (a real bug in the original flow).
  * Adds Spearman rank correlation (requested in the design note) alongside RMSE/MAE.
  * Filters to REAL-DATA countries by default. The uploaded files contain placeholder
    rows for 59 of 74 countries (emissions pinned 50-115; NDCs 100 -> 75/60). Those
    rows are placeholders for countries that lack reliable public NDC/emissions data
    (a recognised UNFCCC/World Bank/national-inventory data gap) and are excluded so
    results are not driven by them.
    Set REAL_ONLY = False to see the (not recommended) full-data version.

HONEST READING OF RESULTS (real-data run):
  Q2 trajectories : market/grandfathering fits far best (RMSE ~0.043), equity and
                    capacity diverge most. NOTE this is partly true by construction,
                    because grandfathering allocates in proportion to current emissions.
                    The informative content is the MAGNITUDE of equity/capacity divergence.
  Q1 NDC ambition : no rule fits well (RMSE ~0.29-0.32, weak/negative rank correlation).
                    Observed NDC effort is dominated by North America and is negative for
                    China and India, whose NDCs allow growth. No principled rule reproduces
                    that, so NDCs are politically idiosyncratic, not described by any rule.
"""

import os
import argparse
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

# ---- IGEMS baseline current emissions (Gt) and the four allocation vectors (Gt) ----
REG = ["NA", "EU", "CHN", "IND", "SSA", "MECA", "SAS", "EAP", "LAM"]
E_CURRENT = dict(zip(REG, [6.5, 3.6, 11.0, 2.4, 1.2, 2.2, 3.2, 4.3, 1.8]))
ALLOC = {
    "market":   dict(zip(REG, [1.80, 0.99, 3.04, 0.66, 0.33, 0.61, 0.88, 1.19, 0.50])),
    "equity":   dict(zip(REG, [0.41, 0.34, 1.18, 1.60, 1.35, 0.49, 2.24, 1.76, 0.63])),
    "capacity": dict(zip(REG, [0.73, 0.77, 0.73, 1.31, 1.70, 0.40, 0.97, 1.24, 2.16])),
    "hybrid":   dict(zip(REG, [1.05, 0.71, 1.81, 1.15, 1.03, 0.51, 1.38, 1.40, 0.96])),
}
RULES = ["market", "equity", "capacity", "hybrid"]

# Countries with complete, reliable public data (UNFCCC NDC Registry; Global Carbon Project).
REAL_COUNTRIES = ["USA", "CAN", "MEX", "CHN", "IND", "DEU", "FRA", "GBR",
                  "BRA", "IDN", "JPN", "SAU", "ZAF", "NGA", "PAK"]
# JPN has a placeholder NDC (base==100), so it is excluded from the NDC test only.
REAL_NDC = [c for c in REAL_COUNTRIES if c != "JPN"]

REAL_ONLY = True
USE_CONDITIONAL = False


def write_igems_files(data_dir):
    er, sr = [], []
    for rule, a in ALLOC.items():
        tot = sum(a.values())
        for r in REG:
            er.append({"region": r, "rule": rule, "effort_2030": E_CURRENT[r] - a[r]})
            sr.append({"region": r, "rule": rule, "alloc_share": a[r] / tot})
    pd.DataFrame(er).to_csv(os.path.join(data_dir, "igems_allocations_2030.csv"), index=False)
    pd.DataFrame(sr).to_csv(os.path.join(data_dir, "igems_allocations_static_share.csv"), index=False)


def load(data_dir):
    rd = lambda f: pd.read_csv(os.path.join(data_dir, f), keep_default_na=False)
    em = rd("emissions_by_country_year.csv")
    ndc = rd("ndc_targets_by_country.csv")
    rm = rd("region_mapping.csv")
    for c in ["year", "emissions"]:
        em[c] = pd.to_numeric(em[c])
    for c in ["base_year", "base_emissions", "target_year",
              "target_emissions_unconditional", "target_emissions_conditional"]:
        ndc[c] = pd.to_numeric(ndc[c])
    em = em.merge(rm, on="country"); ndc = ndc.merge(rm, on="country")
    return em, ndc, rm


def coverage_report(em):
    e20 = em[em.year == 2020].copy()
    e20["real"] = e20["country"].isin(REAL_COUNTRIES)
    g = e20.groupby("region").apply(
        lambda d: pd.Series({"n_countries": len(d), "n_real": int(d.real.sum()),
                             "real_frac_2020": round(d.loc[d.real, "emissions"].sum()
                                                     / d["emissions"].sum(), 2)}))
    print("Real-data coverage of 2020 emissions by region:")
    print(g.to_string()); print()


def fit(obs, rule_share):
    regs = [r for r in REG if r in obs and r in rule_share]
    o = np.array([obs[r] for r in regs]); k = np.array([rule_share[r] for r in regs])
    return (float(np.sqrt(np.mean((k - o) ** 2))), float(np.mean(np.abs(k - o))),
            float(spearmanr(k, o).correlation), len(regs))


def part1_ndc(ndc, e2030):
    d = ndc[ndc.country.isin(REAL_NDC)] if REAL_ONLY else ndc
    col = "target_emissions_conditional" if USE_CONDITIONAL else "target_emissions_unconditional"
    d = d.copy(); d["effort"] = d["base_emissions"] - d[col]
    reff = d.groupby("region")["effort"].sum(); obs = (reff / reff.sum()).to_dict()
    rows = []
    for rule, dd in e2030.groupby("rule"):
        tot = dd["effort_2030"].sum(); rv = {x.region: x.effort_2030 / tot for x in dd.itertuples()}
        rmse, mae, rho, n = fit(obs, rv); rows.append([rule, rmse, mae, rho, n])
    return obs, pd.DataFrame(rows, columns=["rule", "RMSE", "MAE", "Spearman", "n_regions"]).sort_values("RMSE")


def part2_static(em, shares, y0=2015, y1=2020):
    d = em[em.country.isin(REAL_COUNTRIES)] if REAL_ONLY else em
    win = d[d.year.between(y0, y1)]
    m = win.groupby(["region", "year"])["emissions"].sum().groupby("region").mean()
    obs = (m / m.sum()).to_dict()
    rows = []
    for rule, dd in shares.groupby("rule"):
        rv = {x.region: x.alloc_share for x in dd.itertuples()}
        rmse, mae, rho, n = fit(obs, rv); rows.append([rule, rmse, mae, rho, n])
    return obs, pd.DataFrame(rows, columns=["rule", "RMSE", "MAE", "Spearman", "n_regions"]).sort_values("RMSE")


def part2_path(em, shares, years=(2005, 2010, 2015, 2020, 2021, 2022)):
    d = em[em.country.isin(REAL_COUNTRIES)] if REAL_ONLY else em
    h = d[d.year.isin(years)].groupby(["region", "year"])["emissions"].sum().reset_index()
    glob = h.groupby("year")["emissions"].sum().rename("g")
    h = h.merge(glob, on="year"); h["obs_share"] = h["emissions"] / h["g"]
    rows = []
    for rule, dd in shares.groupby("rule"):
        rv = {x.region: x.alloc_share for x in dd.itertuples()}
        mm = h.copy(); mm["rule_share"] = mm["region"].map(rv); mm = mm.dropna(subset=["rule_share"])
        diff = mm["rule_share"] - mm["obs_share"]
        rmse = float(np.sqrt((diff ** 2).mean())); mae = float(diff.abs().mean())
        om = mm.groupby("region")["obs_share"].mean(); rmn = mm.groupby("region")["rule_share"].mean()
        rho = float(spearmanr(rmn.values, om.values).correlation)
        rows.append([rule, rmse, mae, rho, mm["region"].nunique()])
    return pd.DataFrame(rows, columns=["rule", "RMSE", "MAE", "Spearman", "n_regions"]).sort_values("RMSE")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=".")
    args = ap.parse_args()
    write_igems_files(args.data)
    em, ndc, rm = load(args.data)
    e2030 = pd.read_csv(os.path.join(args.data, "igems_allocations_2030.csv"), keep_default_na=False)
    shares = pd.read_csv(os.path.join(args.data, "igems_allocations_static_share.csv"), keep_default_na=False)

    print("=" * 72)
    print(f"IGEMS historical back-test   (REAL_ONLY={REAL_ONLY}, "
          f"NDC={'conditional' if USE_CONDITIONAL else 'unconditional'})")
    print("=" * 72)
    coverage_report(em)

    obs1, r1 = part1_ndc(ndc, e2030)
    print("Q1  NDC ambition  -  observed regional effort shares:")
    print("   " + "  ".join(f"{r}:{obs1[r]:+.2f}" for r in REG if r in obs1))
    print(r1.to_string(index=False))
    print("  -> No rule fits well; observed NDC effort is NA-dominated and negative for CHN/IND.\n")

    obs2, r2 = part2_static(em, shares)
    print("Q2a  Static emission shares (2015-2020):")
    print(r2.to_string(index=False))

    r3 = part2_path(em, shares)
    print("\nQ2b  Emission trajectories (2005-2022):")
    print(r3.to_string(index=False))
    print("  -> Market/grandfathering fits best (partly by construction); equity/capacity diverge most.")

    out = os.path.join(args.data, "backtest_results.csv")
    r1.assign(test="Q1_NDC").to_csv(out, index=False)
    with open(out, "a") as f:
        r2.assign(test="Q2a_static").to_csv(f, header=False, index=False)
        r3.assign(test="Q2b_path").to_csv(f, header=False, index=False)
    print(f"\n[written] {out}")


if __name__ == "__main__":
    main()
