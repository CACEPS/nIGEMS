"""
make_figure.py
==============
Regenerates Figure S7.1 (two panels) into ../results/Fig_strategic_compliance.png:
  Panel a  baseline equilibrium delivered abatement Q* by rule
  Panel b  cooperation (mean Q* across grid) vs burden concentration (max single-region cut)

Run:  python make_figure.py
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import igems_strategic_compliance as M

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "results", "Fig_strategic_compliance.png")

rules = M.RULES
labels = {"market": "Market\n(grandfathering)", "equity": "Equity\n(CBDR+RC)",
          "capacity": "Capacity", "hybrid": "Hybrid\n(cooperative)"}
col = {"market": "#b2182b", "capacity": "#ef8a62", "hybrid": "#2166ac", "equity": "#1a9850"}

baseQ = {r: M.best_equilibrium(r, 3.0, 2.0, 2.0)[0]["Q_delivered_Gt"] for r in rules}
kg, pg, rg = M.default_grid()
meanQ = {}
for r in rules:
    vals = [M.best_equilibrium(r, k, p, rh)[0]["Q_delivered_Gt"]
            for k in kg for p in pg for rh in rg]
    meanQ[r] = float(np.mean(vals))
maxcut = {r: float((np.maximum(0, M.E - M.ALLOC[r]) / M.E * 100).max()) for r in rules}

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12.5, 5.2))
order = sorted(rules, key=lambda r: baseQ[r])
ax1.bar([labels[r] for r in order], [baseQ[r] for r in order],
        color=[col[r] for r in order], edgecolor="black", linewidth=0.6)
for i, r in enumerate(order):
    ax1.text(i, baseQ[r] + 0.15, f"{baseQ[r]:.1f}", ha="center", va="bottom",
             fontsize=11, fontweight="bold")
ax1.set_ylabel("Equilibrium delivered abatement  Q*  (Gt CO$_2$)", fontsize=11)
ax1.set_title("a  Endogenous cooperation at equilibrium", fontsize=12, loc="left", fontweight="bold")
ax1.set_ylim(0, max(baseQ.values()) * 1.2); ax1.grid(axis="y", alpha=0.3)

for r in rules:
    ax2.scatter(maxcut[r], meanQ[r], s=240, color=col[r], edgecolor="black", linewidth=0.8, zorder=3)
    dy = 0.18 if r != "capacity" else -0.34
    ax2.annotate(labels[r].replace("\n", " "), (maxcut[r], meanQ[r] + dy), ha="center",
                 fontsize=10, fontweight="bold")
ax2.annotate("more negotiable\n(lower peak burden)", (74, 13.2), fontsize=9, color="grey", ha="left")
ax2.annotate("", xy=(76, 13.0), xytext=(92, 13.0), arrowprops=dict(arrowstyle="->", color="grey"))
ax2.set_xlabel("Burden concentration: maximum single-region cut (%)", fontsize=11)
ax2.set_ylabel("Cooperation: mean Q* across parameter grid (Gt)", fontsize=11)
ax2.set_title("b  Deliverability vs negotiability", fontsize=12, loc="left", fontweight="bold")
ax2.grid(alpha=0.3); ax2.set_xlim(70, 98)

fig.suptitle("Endogenous strategic compliance: grandfathering is robustly worst; "
             "equity maximises cooperation; hybrid is the negotiable compromise",
             fontsize=11.5, y=1.005)
fig.tight_layout()
os.makedirs(os.path.dirname(OUT), exist_ok=True)
fig.savefig(OUT, dpi=200, bbox_inches="tight")
print("[written]", os.path.relpath(OUT))
