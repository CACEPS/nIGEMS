"""
igems_behavioral_law.py
=======================
Estimation pipeline for the endogenous (reduced-form) behavioural compliance law
described in "Empirical Validation of Endogenous Behavioral Model" (A.Q. Al-Amin).

It estimates, at the nine-region aggregation, a logistic model

    P(y_rt = 1) = logistic( alpha * Fairness_rt  -  beta * Cost_rt  +  tau * regime )

and exports (alpha_hat, beta_hat) for use inside IGEMS as a predicted-compliance
function p_hat(Fairness, Cost).

------------------------------------------------------------------------------
HONEST SCOPE AND CAVEATS  (read before using any output)
------------------------------------------------------------------------------
1. NO DATA IS BUNDLED. The real inputs must be downloaded from authoritative
   public sources (URLs below) and assembled by you. Numbers produced on any
   other basis are NOT empirical estimates and must not enter the manuscript.

2. SMALL, UNBALANCED SAMPLE. Kyoto bound only Annex I parties, so among the nine
   regions only North America and the EU have a defined Kyoto compliance cell.
   The realistic panel is ~2 Kyoto cells + up to 9 Paris cells (~11 obs), and
   Paris compliance is a forward-looking "on track" proxy, not observed outcome.
   At this N: (a) region fixed effects are NOT identified and are dropped here;
   (b) coefficient standard errors are wide; (c) quasi-separation is likely, so a
   penalised (Firth-style) fallback is provided and a leave-one-out check is run.

3. REDUCED FORM, NOT STRATEGIC. This is a correlation of compliance with fairness
   and cost. It does NOT model coalitions, strategic defection, or agent-based
   negotiation. It supports an empirical-grounding claim, not an endogenous
   strategic-behaviour claim.

4. AVOID CIRCULARITY. Define Fairness against an INDEPENDENT fair-share benchmark
   (equal per-capita, or a published GDR / Climate Equity Reference share), NOT
   against the IGEMS allocation you are trying to validate. The loader exposes
   `fair_benchmark` so you can choose; do not default it to the IGEMS equity rule.

------------------------------------------------------------------------------
AUTHORITATIVE PUBLIC SOURCES (download yourself; not reachable from this script)
------------------------------------------------------------------------------
  emissions_by_country_year.csv : Global Carbon Project / Our World in Data
        https://globalcarbonbudget.org   |  https://github.com/owid/co2-data
  gdp_by_country_year.csv       : World Bank WDI (NY.GDP.MKTP.KD)
        https://databank.worldbank.org/source/world-development-indicators
  population_by_country_year.csv: World Bank WDI (SP.POP.TOTL)
  kyoto_targets_by_country.csv  : UNFCCC, Kyoto CP1 quantified commitments (Annex B)
        https://unfccc.int/process/the-kyoto-protocol
  ndc_targets_by_country.csv    : UNFCCC NDC Registry
        https://unfccc.int/NDCREG
  paris_on_track_assessment.csv : Climate Action Tracker country ratings
        https://climateactiontracker.org
  region_mapping.csv            : your country -> 9-region concordance (freeze it)

Required columns are documented in DATA_SCHEMA below. Run estimate_from_csvs(...)
once the CSVs exist. Run synthetic_demo() to see the output format only.
"""

import numpy as np
import pandas as pd
import statsmodels.api as sm
import warnings
from statsmodels.tools.sm_exceptions import PerfectSeparationWarning

REGIONS = ["NA", "EU", "CHN", "IND", "SSA", "MECA", "SAS", "EAP", "LAM"]

DATA_SCHEMA = {
    "emissions_by_country_year.csv": ["country", "year", "emissions"],          # Gt or Mt CO2
    "gdp_by_country_year.csv":       ["country", "year", "gdp"],                # constant USD
    "population_by_country_year.csv": ["country", "year", "population"],
    "kyoto_targets_by_country.csv":  ["country", "allowed_emissions"],          # Annex B only
    "ndc_targets_by_country.csv":    ["country", "ndc_target_emissions", "target_year"],
    "paris_on_track_assessment.csv": ["country", "on_track"],                   # 0/1 from CAT
    "region_mapping.csv":            ["country", "region"],
    # region_obligations.csv: actual vs INDEPENDENT fair-share obligation per region-regime
    "region_obligations.csv":        ["region", "regime", "a_actual", "a_fair"],
}


# ----------------------------------------------------------------------------
# Variable construction (follows the spec; see paper Methods)
# ----------------------------------------------------------------------------
def decarb_rate(emis_region_year: pd.DataFrame, region: str, y0: int, y1: int) -> float:
    """Average annual log decarbonisation rate (1/T) * ln(E_y0 / E_y1)."""
    s = emis_region_year[(emis_region_year.region == region) &
                         (emis_region_year.year.isin([y0, y1]))]
    e0 = float(s.loc[s.year == y0, "emissions"].iloc[0])
    e1 = float(s.loc[s.year == y1, "emissions"].iloc[0])
    return (1.0 / (y1 - y0)) * np.log(e0 / e1)


def build_panel(emissions, region_map, kyoto_reg, paris_reg, obligations,
                kyoto_windows, paris_windows):
    """Assemble the region-regime panel with y, fairness, cost.

    kyoto_reg : DataFrame [region, y]   (compliance 0/1; only Annex-I regions present)
    paris_reg : DataFrame [region, y]   (on-track 0/1 proxy)
    obligations: DataFrame [region, regime, a_actual, a_fair]   (a_fair = INDEPENDENT benchmark)
    kyoto_windows/paris_windows: dict with keys base, target, hist_start, hist_end
    """
    emis = emissions.merge(region_map, on="country")
    emis = emis.groupby(["region", "year"], as_index=False)["emissions"].sum()

    rows = []
    for regime, reg_y, w in [("Kyoto", kyoto_reg, kyoto_windows),
                             ("Paris", paris_reg, paris_windows)]:
        for _, rr in reg_y.iterrows():
            region = rr["region"]
            g_req = decarb_rate(emis, region, w["base"], w["target"])
            g_hist = decarb_rate(emis, region, w["hist_start"], w["hist_end"])
            rows.append({"region": region, "regime": regime,
                         "y": int(rr["y"]), "cost_raw": g_req - g_hist})
    panel = pd.DataFrame(rows)

    obl = obligations.copy()
    obl["fairness_raw"] = -(obl["a_actual"] - obl["a_fair"]).abs()  # closer to fair => higher
    panel = panel.merge(obl[["region", "regime", "fairness_raw"]],
                        on=["region", "regime"], how="left")
    return panel.dropna(subset=["y", "fairness_raw", "cost_raw"]).reset_index(drop=True)


# ----------------------------------------------------------------------------
# Estimation (parsimonious; small-N safe)
# ----------------------------------------------------------------------------
def estimate(panel: pd.DataFrame, use_regime_dummy=True, standardize=True):
    """Fit the logit. Returns dict with coefficients and small-sample diagnostics.

    Region fixed effects are intentionally NOT included (not identified at this N).
    """
    df = panel.copy()
    fr = df["fairness_raw"].to_numpy(float)
    co = df["cost_raw"].to_numpy(float)
    if standardize:
        fr = (fr - fr.mean()) / (fr.std(ddof=0) or 1.0)
        co = (co - co.mean()) / (co.std(ddof=0) or 1.0)
    X = pd.DataFrame({"fairness": fr, "cost": co})
    if use_regime_dummy and df["regime"].nunique() > 1:
        X["regime_Paris"] = (df["regime"] == "Paris").astype(float)
    X = sm.add_constant(X)
    y = df["y"].astype(int).to_numpy()

    out = {"n": len(df), "n_compliant": int(y.sum()), "standardized": standardize}

    # quasi-separation check
    sep = (y.sum() == 0) or (y.sum() == len(y))
    out["degenerate_outcome"] = bool(sep)

    fit_ok = False
    _wctx = warnings.catch_warnings(); _wctx.__enter__()
    warnings.simplefilter('ignore')
    if not sep:
        try:
            res = sm.Logit(y, X).fit(disp=False, maxiter=200)
            if np.all(np.isfinite(res.bse.to_numpy())):
                out["method"] = "MLE logit"
                out["params"] = res.params.to_dict()
                out["se"] = res.bse.to_dict()
                out["pvalues"] = res.pvalues.to_dict()
                out["mcfadden_r2"] = float(res.prsquared)
                out["llr_p"] = float(res.llr_pvalue)
                fit_ok = True
        except Exception as e:
            out["mle_error"] = str(e)

    if not fit_ok and not sep:
        # penalised fallback (ridge) for separation / tiny N; report point estimates only
        res = sm.Logit(y, X).fit_regularized(alpha=1.0, L1_wt=0.0, disp=False)
        out["method"] = "ridge-penalised logit (small-N / separation fallback)"
        out["params"] = dict(zip(X.columns, np.asarray(res.params, float)))
        out["se"] = "not valid under penalisation; bootstrap or Firth recommended"

    _wctx.__exit__(None, None, None)
    if "params" in out:
        out["alpha_hat"] = out["params"].get("fairness")
        out["beta_hat_signed"] = out["params"].get("cost")  # enters model as -beta*Cost
        # leave-one-out stability of the sign of alpha and cost coefficient
        signs = []
        if not sep and len(df) > 4:
            for i in range(len(df)):
                Xi, yi = X.drop(i).reset_index(drop=True), np.delete(y, i)
                try:
                    ri = sm.Logit(yi, Xi).fit(disp=False, maxiter=200)
                    signs.append((np.sign(ri.params["fairness"]), np.sign(ri.params["cost"])))
                except Exception:
                    signs.append((np.nan, np.nan))
            af = np.array([s[0] for s in signs]); cf = np.array([s[1] for s in signs])
            out["loo_sign_stable_fairness"] = bool(np.nanstd(af) == 0)
            out["loo_sign_stable_cost"] = bool(np.nanstd(cf) == 0)
    return out


def predicted_compliance(fairness, cost, alpha, beta_signed):
    z = alpha * np.asarray(fairness, float) + beta_signed * np.asarray(cost, float)
    return 1.0 / (1.0 + np.exp(-z))


def estimate_from_csvs(folder="."):
    """Real-data entry point. Expects the CSVs in DATA_SCHEMA inside `folder`."""
    import os
    g = lambda f: pd.read_csv(os.path.join(folder, f))
    emissions = g("emissions_by_country_year.csv")
    region_map = g("region_mapping.csv")
    obligations = g("region_obligations.csv")  # a_fair = INDEPENDENT benchmark
    kyoto_reg = g("kyoto_compliance_by_region.csv")   # [region, y]  (Annex-I regions only)
    paris_reg = g("paris_ontrack_by_region.csv")      # [region, y]
    kyoto_windows = dict(base=1990, target=2010, hist_start=1980, hist_end=1990)
    paris_windows = dict(base=2010, target=2030, hist_start=1995, hist_end=2010)
    panel = build_panel(emissions, region_map, kyoto_reg, paris_reg, obligations,
                        kyoto_windows, paris_windows)
    panel.to_csv(os.path.join(folder, "behavioural_panel_built.csv"), index=False)
    return panel, estimate(panel)


# ----------------------------------------------------------------------------
# SYNTHETIC smoke test  ->  shows OUTPUT FORMAT ONLY.  NUMBERS ARE MEANINGLESS.
# ----------------------------------------------------------------------------
def synthetic_demo(seed=0):
    print("=" * 72)
    print("  SYNTHETIC SMOKE TEST  --  NOT REAL RESULTS  --  DO NOT CITE")
    print("  Inputs are random draws; coefficients carry no scientific meaning.")
    print("  Purpose: confirm the pipeline runs and show the output format.")
    print("=" * 72)
    rng = np.random.default_rng(seed)
    # realistic small, unbalanced panel: 2 Kyoto cells (NA, EU) + 9 Paris cells
    rows = []
    for region in ["NA", "EU"]:
        rows.append({"region": region, "regime": "Kyoto"})
    for region in REGIONS:
        rows.append({"region": region, "regime": "Paris"})
    df = pd.DataFrame(rows)
    df["fairness_raw"] = rng.normal(0, 1, len(df))     # synthetic
    df["cost_raw"] = rng.normal(0, 1, len(df))         # synthetic
    true_alpha, true_beta = 1.3, 1.1                   # synthetic DGP
    z = true_alpha * df["fairness_raw"] - true_beta * df["cost_raw"] + rng.normal(0, 0.5, len(df))
    df["y"] = (1.0 / (1.0 + np.exp(-z)) > rng.uniform(0, 1, len(df))).astype(int)

    print(f"\nPanel (synthetic): n = {len(df)}  "
          f"(Kyoto cells = 2: NA, EU; Paris cells = 9)\n")
    print(df.to_string(index=False))
    res = estimate(df, use_regime_dummy=True, standardize=True)
    print("\n--- estimate() output (SYNTHETIC) ---")
    for k, v in res.items():
        print(f"  {k}: {v}")
    print("\nReminder: real alpha_hat/beta_hat require the authoritative data in")
    print("DATA_SCHEMA. These synthetic numbers must not appear in the manuscript.")
    print("=" * 72)
    return res


if __name__ == "__main__":
    synthetic_demo()
