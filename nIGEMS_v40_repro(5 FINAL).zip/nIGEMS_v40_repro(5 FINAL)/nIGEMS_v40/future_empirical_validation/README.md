# Future empirical validation (NOT part of the S7 results)

`igems_behavioral_law.py` implements the reduced-form logit behavioural law
(P(comply) as a function of fairness and cost) over a nine-region, two-regime panel.

It is included for completeness and future use. It produces **no results here**,
because it requires authoritative public data that must be downloaded by the user:

- Emissions: Global Carbon Project / Our World in Data
- GDP, population: World Bank WDI
- Kyoto targets: UNFCCC Annex B
- NDCs: UNFCCC NDC Registry
- Paris "on track": Climate Action Tracker

Exact column schemas and source URLs are documented in the file header.

Important caveats (also in the file):
- The honest sample is small (~11 region-regime cells) and unbalanced, because Kyoto
  bound only Annex I parties. Region fixed effects are therefore not identified.
- The model is reduced-form, not strategic; it supports empirical grounding, not the
  endogenous-mechanism point that Supplementary Note S7 addresses.
- Use an INDEPENDENT fair-share benchmark (equal per-capita or a published equity
  reference), not the IGEMS allocation, to avoid circularity.

Run a synthetic smoke test (shows the output format only; numbers are meaningless):
    python3 igems_behavioral_law.py
