$title IGEMS v40 - Integrated Global Emissions Management System (all-in-one)

$onText
================================================================================
 IGEMS v40 - ALL-IN-ONE GAMS MODEL (honest re-anchored version)
 Reproduces the outcomes in IGEMS_N_CC_v40_AlAmin.docx.

 KEY DIFFERENCES FROM THE EARLIER .gms (corrections):
   1. All four allocation vectors are NORMALISED to the 10 Gt budget, so the
      "identical physical constraint" of the channel-isolation design actually
      holds (previously equity summed to 11.0 Gt and capacity to 25.7 Gt).
   2. Compliance is the OPTION B trajectory-convergence metric (capacity-graded
      feasible decarbonization), computed - not stipulated. The old file printed
      hard-coded text ("0.22 / 0.78 [BEST]") that contradicted what it computed;
      that text is removed. All reported numbers below are computed live.
   3. Adds a continuous corridor-adherence variant, a stochastic module, a Gini
      index, and a bounded stylised marginal-abatement-cost (MAC) layer.

 RUN:
   gams IGEMS_complete_v40.gms                 (deterministic: B, C, MAC, 6-metric, fund)
   gams IGEMS_complete_v40.gms --STOCH=1       (+ Monte Carlo: B, C, climate)
   gams IGEMS_complete_v40.gms --OPTIM=1       (+ Nash weight NLP; needs NLP solver)
   gams IGEMS_complete_v40.gms --STRUCT=1      (+ structural-sensitivity sweep)

 NOTE: GAMS native RNG differs from the Python runner, so the stochastic numbers
 are close but not bit-identical to igems_optionB.py. The deterministic, Gini,
 and MAC results are closed-form and match the Python results exactly.
================================================================================
$offText

* ==============================================================================
* 1. SETS
* ==============================================================================
Set i 'nine macro-regions'
    / NA 'North America', EU 'Europe', CHN 'China', IND 'India',
      SSA 'Sub-Saharan Africa', MECA 'Middle East and Central Asia',
      SAS 'South Asia', EAP 'East Asia and Pacific', LAM 'Latin America' / ;
Alias (i,j);

Set t 'simulation years 2024-2074 (51-year horizon, corridor reaches A at 2074)'
    / 2024*2074 / ;

Set m 'allocation mechanisms' / market, equity, capacity, hybrid / ;

* ==============================================================================
* 2. BASELINE DATA (2024) - real 9-region baseline (manuscript Table 2)
* ==============================================================================
Table d(i,*)
            pop      gdp      emis    hist    forest
   NA       0.58     28.0     6.5     400     0.33
   EU       0.45     19.0     3.6     320     0.35
   CHN      1.43     17.0    11.0      90     0.23
   IND      1.44      3.7     2.4      35     0.23
   SSA      1.20      2.1     1.2      12     0.30
   MECA     0.50      2.8     2.2      18     0.09
   SAS      2.00      4.2     3.2      28     0.17
   EAP      1.80      9.5     4.3      45     0.28
   LAM      0.65      3.4     1.8      35     0.49 ;

Scalars
   B      'annual global budget, Gt CO2'        / 10.0 /
   Kmac   'MAC calibration: 72% cut -> ~100 USD/t' ;
Kmac = 100/0.72;

Parameters Etot, Ptot, Htot, meanG, gpc(i), bench, denom;
Etot   = sum(i, d(i,'emis'));
Ptot   = sum(i, d(i,'pop'));
Htot   = sum(i, d(i,'hist'));
gpc(i) = d(i,'gdp')/d(i,'pop')*1000;
meanG  = sum(i, d(i,'gdp'))/Ptot*1000;
bench  = B/7.87;
denom  = card(t) - 1;

* ==============================================================================
* 3. ALLOCATION MECHANISMS (raw, then normalised to the budget)
* ==============================================================================
Parameters allocN(m,i), hybRaw(i);

* Canonical allocation vectors (the documented model inputs, base_allocations.csv).
* Using these reproduces the manuscript exactly. The closed-form derivations are
* kept below in comments for reference; market is in any case emis-proportional.
Table allocC(i,m)
            market   equity   capacity
   NA       1.80     0.45     1.87
   EU       0.99     0.37     1.98
   CHN      3.04     1.30     1.86
   IND      0.66     1.77     3.35
   SSA      0.33     1.49     4.37
   MECA     0.61     0.54     1.02
   SAS      0.88     2.47     2.48
   EAP      1.19     1.94     3.17
   LAM      0.50     0.70     5.55 ;

Scalars wM /0.40/, wE /0.35/, wC /0.25/;

* Normalise the three base mechanisms to the budget individually ...
allocN('market',i)   = allocC(i,'market')   * B / sum(j, allocC(j,'market'));
allocN('equity',i)   = allocC(i,'equity')   * B / sum(j, allocC(j,'equity'));
allocN('capacity',i) = allocC(i,'capacity') * B / sum(j, allocC(j,'capacity'));
* ... then form the hybrid as the budget-normalised blend of the NORMALISED bases
* (manuscript convention; reproduces hybrid adherence ~0.94 and cost index ~105).
hybRaw(i)          = wM*allocN('market',i) + wE*allocN('equity',i) + wC*allocN('capacity',i);
allocN('hybrid',i) = hybRaw(i) * B / sum(j, hybRaw(j));


$onText
 Reference (closed-form) derivations used to generate the canonical vectors:
   market   : emis_i / sum(emis) * B
   equity   : Bi - Hi + Di, with Bi = pop_i/Ptot*B, Hi = hist_i/Htot*0.40*Bi,
              Di = +0.25/+0.10/-0.05 * Bi by income tier (CBDR+RC)
   capacity : min(2*forest_i,1)/sum(forest) * B * Mi, Mi = 1.8/1.4/1.0/0.7 by tier
$offText

* ==============================================================================
* 4. CAPACITY-GRADED FEASIBLE DECARBONIZATION RATE (independent of allocation)
*    1.5%/yr lowest-income ... 3.5%/yr highest-income (within 3.9 range).
*    This fixes reachability by capacity, so the test below is NOT circular.
* ==============================================================================
Parameter dmax(i);
dmax(i)                       = 0.035;
dmax(i)$(gpc(i) <  1.5*meanG) = 0.025;
dmax(i)$(gpc(i) <  0.7*meanG) = 0.020;
dmax(i)$(gpc(i) <  0.3*meanG) = 0.015;

* ==============================================================================
* 5. OPTION B - TRAJECTORY-CONVERGENCE COMPLIANCE (computed)
*    corridor T(i,t) = E0 * (A/E0)^((t-1)/(T-1))    [glide to allocation by 2074]
*    actual  E(i,t)  = E0 * (1 - dmax)^(t-1)         [best feasible effort]
*    compliant in year t iff actual <= corridor.
* ==============================================================================
Parameters actualB(i,t), corridor(m,i,t), comp(m,i,t),
           CR(m), adh(m,i,t), CRcont(m), p15(m);

actualB(i,t)    = d(i,'emis') * (1 - dmax(i))**(ord(t)-1);
corridor(m,i,t) = d(i,'emis') * (allocN(m,i)/d(i,'emis'))**((ord(t)-1)/denom);

comp(m,i,t) = 0;
comp(m,i,t)$(actualB(i,t) <= corridor(m,i,t) + 1e-9) = 1;
CR(m) = sum((i,t), comp(m,i,t)) / (card(i)*card(t));

* continuous corridor-adherence variant (1 if on/under corridor, else how close)
adh(m,i,t)  = min(1, corridor(m,i,t)/actualB(i,t));
CRcont(m)   = sum((i,t), adh(m,i,t)) / (card(i)*card(t));

* illustrative heuristic bands (NOT primary; shown for comparison only)
p15(m)                 = 20;
p15(m)$(CR(m) >= 0.40) = 50;
p15(m)$(CR(m) >  0.70) = 85;

* ==============================================================================
* 6. EQUITY METRICS: per-capita ratio + Gini (mean-absolute-difference form)
* ==============================================================================
Parameters pcap(m,i), pcratio(m), meanpc(m), gini(m), avgJi(m), Ji(m,i);
pcap(m,i)   = allocN(m,i)/d(i,'pop');
pcratio(m)  = smax(i, pcap(m,i)) / smin(i, pcap(m,i));
meanpc(m)   = sum(i, pcap(m,i))/card(i);
gini(m)     = sum((i,j), abs(pcap(m,i)-pcap(m,j))) / (2*sqr(card(i))*meanpc(m));
Ji(m,i)     = max(0, 100 - abs((pcap(m,i)-bench)/bench)*100);
avgJi(m)    = sum(i, Ji(m,i))/card(i);

* ==============================================================================
* 7. BOUNDED STYLISED MAC COST LAYER (Supplementary Note S1; secondary)
*    Allocations are fixed exogenous constraints; never re-optimised here.
*    Convex regional cost C_i = 0.5 * b_i * R_i^2 ;  b_i = Kmac / E0_i.
* ==============================================================================
Parameters Rabate(m,i), bslope(i), cost(m,i), totcost(m), costindex(m),
           price(m,i), meanprice(m), maxshare(m);
bslope(i)    = Kmac / d(i,'emis');
Rabate(m,i)  = max(0, d(i,'emis') - allocN(m,i));
cost(m,i)    = 0.5 * bslope(i) * sqr(Rabate(m,i));
price(m,i)   = bslope(i) * Rabate(m,i);
totcost(m)   = sum(i, cost(m,i));
costindex(m) = totcost(m) / sum(i, cost('market',i)) * 100;
meanprice(m) = sum(i, price(m,i)*d(i,'emis')) / Etot;
maxshare(m)  = smax(i, cost(m,i)) / totcost(m) * 100;

* ==============================================================================
* 8. DETERMINISTIC REPORT (all values computed live)
* ==============================================================================
Parameter REPORT(m,*);
REPORT(m,'alloc_sum_Gt')      = sum(i, allocN(m,i));
REPORT(m,'CR_trajconv')       = CR(m);
REPORT(m,'CR_continuous_adh') = CRcont(m);
REPORT(m,'heuristic_p15_pct') = p15(m);
REPORT(m,'percap_ratio')      = pcratio(m);
REPORT(m,'gini_percap')       = gini(m);
REPORT(m,'cost_index_mkt100') = costindex(m);
REPORT(m,'mean_price_usd_t')  = meanprice(m);
REPORT(m,'cost_maxshare_pct') = maxshare(m);

display allocN, dmax, REPORT;
display 'Expected (matches v40): CR market~0.24, equity/capacity/hybrid~0.46;';
display 'continuous adherence hybrid~0.94; cost index mkt100/hyb105/equ114/cap120.';

* ==============================================================================
* 9. STOCHASTIC MODULE (Monte Carlo)  --  run with  --STOCH=1
*    GAMS-native RNG; close to but not identical to the Python ensemble.
* ==============================================================================
$if not set STOCH $goto skipstoch
Set sc 'Monte Carlo scenarios' / s1*s1000 / ;
Scalar sigln; sigln = log(1.15);
execseed = 42;
Parameters emult(i), rmult(i), shock(i), ds(i), e0s(i),
           actS(i,t), corS(m,i,t), crs(sc,m),
           MCmean(m), MCsd(m), Phigh(m), CIlo(m), CIhi(m);

loop(sc,
   emult(i) = exp( normal(0, sigln) - 0.5*sqr(sigln) );
   rmult(i) = 0.7 + 0.6*min(1, max(0, normal(0.5, 0.118)));
   shock(i) = max(0.05, normal(1, 0.3333));
   ds(i)    = min(0.06, max(0.005, dmax(i)*rmult(i)));
   e0s(i)   = d(i,'emis')*emult(i);
   actS(i,t)    = e0s(i)*(1-ds(i))**(ord(t)-1) * shock(i);
   corS(m,i,t)  = e0s(i)*(allocN(m,i)/e0s(i))**((ord(t)-1)/denom);
   crs(sc,m)    = sum((i,t)$(actS(i,t) <= corS(m,i,t) + 1e-9), 1) / (card(i)*card(t));
);

MCmean(m) = sum(sc, crs(sc,m))/card(sc);
MCsd(m)   = sqrt( sum(sc, sqr(crs(sc,m)-MCmean(m)))/card(sc) );
Phigh(m)  = sum(sc$(crs(sc,m) > 0.70), 1)/card(sc);
CIlo(m)   = max(0, MCmean(m) - 1.96*MCsd(m));
CIhi(m)   = min(1, MCmean(m) + 1.96*MCsd(m));

Parameter MCREPORT(m,*);
MCREPORT(m,'mean')        = MCmean(m);
MCREPORT(m,'sd')          = MCsd(m);
MCREPORT(m,'CI95_lo_approx') = CIlo(m);
MCREPORT(m,'CI95_hi_approx') = CIhi(m);
MCREPORT(m,'P_CR_gt_0p70') = Phigh(m);
display MCREPORT;
display 'Note: CI is a normal approximation; exact percentiles are in igems_optionB.py.';
$label skipstoch

* ==============================================================================
* 10. ENDOGENOUS WEIGHTS - Nash bargaining NLP  --  run with  --OPTIM=1
*     Illustrative; the canonical endogenous-weights result is in the Python
*     runner. Maximises sum_i log(per-capita gain over the market status quo).
* ==============================================================================
$if not set OPTIM $goto skipoptim
Set k 'weight components' / wk_mkt, wk_equ, wk_cap / ;
Positive Variables wv(k);
Variables nashobj;
Parameter mbase(i), ebase(i), cbase(i);
mbase(i) = allocN('market',i); ebase(i) = allocN('equity',i); cbase(i) = allocN('capacity',i);

Equations sumw, objdef;
sumw.. sum(k, wv(k)) =e= 1;
* Illustrative Nash/welfare objective: maximise sum_i log(per-capita allocation).
* Smooth and concave; the canonical endogenous-weights result is in the Python runner.
objdef.. nashobj =e=
   sum(i, log( ( wv('wk_mkt')*mbase(i) + wv('wk_equ')*ebase(i)
               + wv('wk_cap')*cbase(i) ) / d(i,'pop') + 1e-4 ) );

wv.lo(k) = 0; wv.up(k) = 1;
wv.l('wk_mkt') = 0.40; wv.l('wk_equ') = 0.35; wv.l('wk_cap') = 0.25;
Model nash / sumw, objdef /;
solve nash using nlp maximizing nashobj;
display wv.l, nashobj.l;
display 'Illustrative weights (market:equity:capacity); canonical values in the Python runner.';
$label skipoptim

* ==============================================================================
* 11. OPTION C - ACCEPTANCE-WEIGHTED COMPLIANCE (behavioural; comparative)
*     Compliance probability declines with the required cut depth (logistic),
*     grounded in the political-acceptance / fair-burden literature. This is a
*     parallel behavioural specification (Supplementary Note S2), reported for
*     comparison; the main text uses Option B.
*       f(m,i) = max(0, 1 - A/E0)                 required cut
*       p(m,i) = 1 / (1 + exp(Kc*(f - f0)))       acceptance probability
* ==============================================================================
Scalars f0 'tolerance midpoint' /0.50/, Kc 'steepness' /8.0/, spanC 'capacity span' /0.30/, maxgpc;
maxgpc = smax(i, gpc(i));
Parameters fcut(m,i), pacc(m,i), f0cap(i), pacccap(m,i),
           CRc_uni(m), CRc_uniPW(m), CRc_cap(m), CRc_capPW(m), CREPORT(m,*);

fcut(m,i)    = max(0, 1 - allocN(m,i)/d(i,'emis'));
pacc(m,i)    = 1/(1 + exp( Kc*(fcut(m,i) - f0) ));
CRc_uni(m)   = sum(i, pacc(m,i))/card(i);
CRc_uniPW(m) = sum(i, pacc(m,i)*d(i,'pop'))/Ptot;

* capacity-adjusted tolerance (CBDR): wealthier regions tolerate deeper cuts
f0cap(i)       = f0 + spanC*(gpc(i)/maxgpc);
pacccap(m,i)   = 1/(1 + exp( Kc*(fcut(m,i) - f0cap(i)) ));
CRc_cap(m)     = sum(i, pacccap(m,i))/card(i);
CRc_capPW(m)   = sum(i, pacccap(m,i)*d(i,'pop'))/Ptot;

CREPORT(m,'CRc_uniform')        = CRc_uni(m);
CREPORT(m,'CRc_uniform_popwt')  = CRc_uniPW(m);
CREPORT(m,'CRc_capacity_adj')   = CRc_cap(m);
CREPORT(m,'CRc_capacity_popwt') = CRc_capPW(m);

display CREPORT, pacc;
display 'Expected (matches Option C study): uniform popwt market~0.14, capacity~0.34,';
display 'hybrid~0.36, equity~0.48 (equity highest on acceptance; market lowest).';

* Optional: Monte Carlo for Option C (varies f0, Kc, emissions)  --  --STOCH=1
$if not set STOCH $goto skipstochC
Parameters f0s, Kcs, ems(i), fc_s(m,i), crCs(sc,m), MCCmean(m), MCCsd(m), MCCphigh(m);
execseed = 77;
loop(sc,
   f0s = uniform(0.40, 0.60);
   Kcs = uniform(6.0, 10.0);
   ems(i) = exp( normal(0, sigln) - 0.5*sqr(sigln) );
   fc_s(m,i) = max(0, 1 - allocN(m,i)/(d(i,'emis')*ems(i)));
   crCs(sc,m) = sum(i, ( 1/(1+exp(Kcs*(fc_s(m,i)-f0s))) )*d(i,'pop'))/Ptot;
);
MCCmean(m)  = sum(sc, crCs(sc,m))/card(sc);
MCCsd(m)    = sqrt( sum(sc, sqr(crCs(sc,m)-MCCmean(m)))/card(sc) );
MCCphigh(m) = sum(sc$(crCs(sc,m) > 0.70), 1)/card(sc);
Parameter MCCREPORT(m,*);
MCCREPORT(m,'mean')        = MCCmean(m);
MCCREPORT(m,'sd')          = MCCsd(m);
MCCREPORT(m,'P_CR_gt_0p70') = MCCphigh(m);
display MCCREPORT;
$label skipstochC

* ==============================================================================
* 12. ROBUSTNESS ACROSS SIX COMPLIANCE / FEASIBILITY METRICS (#2)
*     Reuses CR (binary), CRcont (continuous), CRc_uniPW (acceptance, Sec 11),
*     costindex (Sec 7); adds overshoot and cross-metric regret.
* ==============================================================================
Parameters overshoot(m), adhreg(m,i), bestreg(i), regret(m), costadj(m), SIXREPORT(m,*);
overshoot(m) = sum((i,t), max(0, actualB(i,t) - corridor(m,i,t))) / sum((i,t), corridor(m,i,t));
adhreg(m,i)  = sum(t, min(1, corridor(m,i,t)/actualB(i,t))) / card(t);
bestreg(i)   = smax(m, adhreg(m,i));
regret(m)    = sum(i, bestreg(i) - adhreg(m,i)) / card(i);
costadj(m)   = CRcont(m) / (costindex(m)/100);
SIXREPORT(m,'binary')        = CR(m);
SIXREPORT(m,'continuous')    = CRcont(m);
SIXREPORT(m,'acceptance_pw') = CRc_uniPW(m);
SIXREPORT(m,'cost_adjusted') = costadj(m);
SIXREPORT(m,'overshoot')     = overshoot(m);
SIXREPORT(m,'regret')        = regret(m);
display SIXREPORT;
display 'Higher better: binary, continuous, acceptance, cost_adjusted. Lower better: overshoot, regret.';
display 'Expected: hybrid lowest regret (~0.045) and never worst; market worst on binary/acceptance.';

* ==============================================================================
* 13. STYLISED TWO-BLOC PARTICIPATION (#5)  (illustrative, not equilibrium)
* ==============================================================================
Set hi(i) 'high-emitting bloc'  / NA, EU, CHN, MECA, EAP /;
Set lo(i) 'lower-income bloc'    / IND, SSA, SAS, LAM /;
Parameters blocHi(m), blocLo(m);
blocHi(m) = sum(hi, pacc(m,hi)*d(hi,'pop')) / sum(hi, d(hi,'pop'));
blocLo(m) = sum(lo, pacc(m,lo)*d(lo,'pop')) / sum(lo, d(lo,'pop'));
display blocHi, blocLo;
display 'A bloc participates if pop-weighted acceptance > 0.5. No rule wins BOTH blocs:';
display 'lower-income bloc participates under equity/capacity/hybrid; high-emitter bloc never does.';

* ==============================================================================
* 14. STYLISED TCRE TEMPERATURE / OVERSHOOT LAYER (#8)   --  --STOCH=1
*     Realised emissions = accepted regions follow allocation glide; others
*     decarbonise slowly (~1%/yr). Cumulative -> TCRE warming + budget exceedance.
* ==============================================================================
$if not set STOCH $goto skipclim
Scalars tcre, f0c, kkc, cumE;
Parameters pAcc(i), realE(i,t), warmM(m), exc15(m), exc20(m);
execseed = 99;
warmM(m) = 0; exc15(m) = 0; exc20(m) = 0;
loop(sc,
   tcre = normal(0.45, 0.09)/1000;
   f0c  = uniform(0.40, 0.60);
   kkc  = uniform(6.0, 10.0);
   loop(m,
      pAcc(i)   = 1/(1+exp( kkc*( max(0,1-allocN(m,i)/d(i,'emis')) - f0c) ));
      realE(i,t)= pAcc(i)*( d(i,'emis')*(allocN(m,i)/d(i,'emis'))**((ord(t)-1)/denom) )
                + (1-pAcc(i))*( d(i,'emis')*(1-0.010)**(ord(t)-1) );
      cumE = sum((i,t), realE(i,t));
      warmM(m) = warmM(m) + (1.24 + tcre*cumE);
      exc15(m) = exc15(m) + 1$(cumE > 340);
      exc20(m) = exc20(m) + 1$(cumE > 990);
   );
);
warmM(m) = warmM(m)/card(sc); exc15(m) = exc15(m)/card(sc); exc20(m) = exc20(m)/card(sc);
Parameter CLIMREPORT(m,*);
CLIMREPORT(m,'peak_warming_C') = warmM(m);
CLIMREPORT(m,'P_exceed_1p5')   = exc15(m);
CLIMREPORT(m,'P_exceed_2p0')   = exc20(m);
display CLIMREPORT;
display 'Expected: ~1.86-1.90 C all mechanisms; P(exceed 1.5C)=1. Governance has small';
display 'leverage on peak warming given a fixed physical pathway; its leverage is distributional.';
$label skipclim

* ==============================================================================
* 15. STRUCTURAL SENSITIVITY (#6/#7)  --  --STRUCT=1
*     Re-derive allocations from formulas while varying historical coefficient,
*     income thresholds, forest multiplier, and hybrid weights. Check whether the
*     qualitative ordering (market least reachable; hybrid lowest regret) survives.
* ==============================================================================
$if not set STRUCT $goto skipstruct
Set scs 'structural draws' / 1*400 /;
Scalars SumForest, hc, th1, th2, th3, fm, u1, u2, u3, ws, mw, hr;
Parameters Bi2(i), Hi2(i), Di2(i), Fi2(i), Mi2(i),
           amkt(i), aequ(i), acap(i), nmk(i), neq(i), nca(i), hraw(i), nhy(i),
           crX(m), adX(m,i), bst(i);
SumForest = sum(i, d(i,'forest'));
execseed = 123;  mw = 0;  hr = 0;
loop(scs,
   hc = uniform(0.20,0.60);
   th1= uniform(0.25,0.35); th2= uniform(0.60,0.80); th3= uniform(1.30,1.70);
   fm = uniform(1.5,2.5);
   u1 = uniform(0.05,1); u2 = uniform(0.05,1); u3 = uniform(0.05,1); ws = u1+u2+u3;
   amkt(i) = d(i,'emis')/Etot*B;
   Bi2(i)  = d(i,'pop')/Ptot*B;
   Hi2(i)  = d(i,'hist')/Htot*hc*Bi2(i);
   Di2(i)  = -0.05*Bi2(i);
   Di2(i)$(gpc(i) <= meanG)     = 0.10*Bi2(i);
   Di2(i)$(gpc(i) <  0.5*meanG) = 0.25*Bi2(i);
   aequ(i) = max(0, Bi2(i) - Hi2(i) + Di2(i));
   Fi2(i)  = min(d(i,'forest')*fm, 1.0);
   Mi2(i)  = 0.7;
   Mi2(i)$(gpc(i) < th3*meanG) = 1.0;
   Mi2(i)$(gpc(i) < th2*meanG) = 1.4;
   Mi2(i)$(gpc(i) < th1*meanG) = 1.8;
   acap(i) = Fi2(i)/SumForest*B*Mi2(i);
   nmk(i)  = amkt(i)*B/sum(j,amkt(j));
   neq(i)  = aequ(i)*B/sum(j,aequ(j));
   nca(i)  = acap(i)*B/sum(j,acap(j));
   hraw(i) = (u1/ws)*nmk(i) + (u2/ws)*neq(i) + (u3/ws)*nca(i);
   nhy(i)  = hraw(i)*B/sum(j,hraw(j));
   crX('market')   = sum((i,t)$(actualB(i,t) <= d(i,'emis')*(nmk(i)/d(i,'emis'))**((ord(t)-1)/denom)+1e-9),1)/(card(i)*card(t));
   crX('equity')   = sum((i,t)$(actualB(i,t) <= d(i,'emis')*(neq(i)/d(i,'emis'))**((ord(t)-1)/denom)+1e-9),1)/(card(i)*card(t));
   crX('capacity') = sum((i,t)$(actualB(i,t) <= d(i,'emis')*(nca(i)/d(i,'emis'))**((ord(t)-1)/denom)+1e-9),1)/(card(i)*card(t));
   crX('hybrid')   = sum((i,t)$(actualB(i,t) <= d(i,'emis')*(nhy(i)/d(i,'emis'))**((ord(t)-1)/denom)+1e-9),1)/(card(i)*card(t));
   adX('market',i)   = sum(t, min(1, (d(i,'emis')*(nmk(i)/d(i,'emis'))**((ord(t)-1)/denom))/actualB(i,t)))/card(t);
   adX('equity',i)   = sum(t, min(1, (d(i,'emis')*(neq(i)/d(i,'emis'))**((ord(t)-1)/denom))/actualB(i,t)))/card(t);
   adX('capacity',i) = sum(t, min(1, (d(i,'emis')*(nca(i)/d(i,'emis'))**((ord(t)-1)/denom))/actualB(i,t)))/card(t);
   adX('hybrid',i)   = sum(t, min(1, (d(i,'emis')*(nhy(i)/d(i,'emis'))**((ord(t)-1)/denom))/actualB(i,t)))/card(t);
   bst(i) = smax(m, adX(m,i));
   mw = mw + 1$( crX('market') le smin(m, crX(m)) + 1e-12 );
   hr = hr + 1$( sum(i,bst(i)-adX('hybrid',i)) <= smin(m, sum(i,bst(i)-adX(m,i))) + 1e-9 );
);
display 'Structural sensitivity over 400 draws:';
display mw, hr;
display 'mw = count where market is least reachable; hr = count where hybrid has lowest regret.';
display 'Expected: mw ~= 400 (100%), hr ~= 398 (99.5%).';
$label skipstruct

* ==============================================================================
* 16. SOLIDARITY FUND DERIVATION (Action 3; deterministic)
*     Burden the hybrid shifts off lower-income regions, priced at IPCC AR6
*     carbon values. Reproduces the Section 6.3 figures.
* ==============================================================================
Parameters gainH(i), lossH(i);
Scalars totGain, totLoss, fund140, fund340, fund430, fund990;
gainH(i) = max(0, allocN('hybrid',i) - allocN('market',i));
lossH(i) = max(0, allocN('market',i) - allocN('hybrid',i));
totGain  = sum(i, gainH(i));
totLoss  = sum(i, lossH(i));
* Gt/yr x $/t  ==  $ billion/yr  (1 Gt * $1/t = $1e9 = $1 bn)
fund140 = totGain*140;  fund340 = totGain*340;  fund430 = totGain*430;  fund990 = totGain*990;
display gainH, totGain, totLoss;
display 'Redistributed burden ~2.36 Gt/yr. Fund ($bn/yr) at IPCC AR6 prices:';
display fund140, fund340, fund430, fund990;
display 'At 1.5C prices (430-990/t): ~$1.0-2.3 trillion/yr; $1T is the conservative floor,';
display 'corroborated by IHLEG (Songwe, Stern & Bhattacharya 2022, ~$1T/yr external finance).';

* ==============================================================================
* 17. PER-CAPITA RATIO + TABLE 5 EQUITY-CUT CHECK (v40, single convention)
*     The whole model uses ONE convention: normalize each base mechanism to the
*     10 Gt budget, blend 40:35:25, renormalise (allocN above). Every allocation
*     sums to 10 Gt; Table 5, per-capita, compliance and cost all use these.
*     Per-capita hybrid ratio ~2.6; market ~11.1.
* ==============================================================================
Parameters pc(i);
Scalars ratioMkt, ratioHyb;
pc(i)    = allocN('hybrid',i)/d(i,'pop');
ratioHyb = smax(i,pc(i))/smin(i,pc(i));
ratioMkt = smax(i, allocN('market',i)/d(i,'pop')) / smin(i, allocN('market',i)/d(i,'pop'));
display ratioMkt, ratioHyb;
display 'Per-capita ratio: market ~11.1; hybrid ~2.6 (single convention, budget-normalised).';

* Table 5 equity-cut check: a region is a development surplus only if its equity
* allocation exceeds current emissions. Only Sub-Saharan Africa qualifies; India
* and South Asia have equity allocations BELOW current emissions and must cut.
Parameters eqCutPct(i);
eqCutPct(i) = 100*max(0, 1 - allocN('equity',i)/d(i,'emis'));
display eqCutPct;
display 'Equity cuts: only SSA is a development surplus (0% cut); India ~33%, South Asia ~30%.';

* (No hard-coded summary text. Every number above is computed by the model.)
